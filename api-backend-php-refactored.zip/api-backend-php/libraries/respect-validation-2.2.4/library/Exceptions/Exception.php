<?php

/*
 * This file is part of Respect/Validation.
 *
 * (c) Alexandre Gomes Gaigalas <alganet@gmail.com>
 *
 * For the full copyright and license information, please view the LICENSE file
 * that was distributed with this source code.
 */

declare(strict_types=1);

namespace Respect\Validation\Exceptions;

use Throwable;

/**
 * @author Andy Wendt <andy@awendt.com>
 * @author Henrique Moody <henriquemoody@gmail.com>
 */
interface Exception extends Throwable
{
}
