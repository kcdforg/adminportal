<?php

declare(strict_types=1);

$database = $bootstrap['database'];

try {
    $payload = checkAuth();
} catch (RuntimeException $exception) {
    errorResponse('UNAUTHENTICATED', $exception->getMessage(), 401);
}

$profileId = (int) ($payload['profile_id'] ?? 0);
if ($profileId <= 0) {
    errorResponse('UNAUTHENTICATED', 'The token is missing profile information.', 401);
}

$user = $database->get('user_logins', [
    'id', 'username', 'email', 'first_name', 'last_name', 'is_active',
    'created_at', 'updated_at', 'last_login_at',
], ['id' => $profileId]);
$profileType = null;

if (!$user) {
    $user = $database->get('family_members', [
        'id', 'name', 'email', 'phone', 'status', 'created_at', 'updated_at',
    ], ['id' => $profileId]);
    $profileType = 'family_member';
}

if (!$user) {
    $user = $database->get('trainers', [
        'id', 'username', 'email', 'first_name', 'last_name', 'is_active',
        'created_at', 'updated_at',
    ], ['id' => $profileId]);
    $profileType = 'trainer';
}

if (!$user) {
    $user = $database->get('admins', [
        'id', 'username', 'email', 'first_name', 'last_name', 'is_active',
        'created_at', 'updated_at',
    ], ['id' => $profileId]);
    $profileType = 'admin';
}

if (!$user) {
    errorResponse('PROFILE_NOT_FOUND', 'The authenticated profile could not be found.', 404);
}

$roles = array_values(array_unique(array_filter(
    array_map('strval', (array) ($payload['roles'] ?? []))
)));

$firstName = (string) ($user['first_name'] ?? '');
$lastName = (string) ($user['last_name'] ?? '');
$name = trim((string) ($user['name'] ?? '')) ?: trim($firstName . ' ' . $lastName);

successResponse([
    'id' => (int) ($user['id'] ?? 0),
    'username' => (string) ($user['username'] ?? $user['email'] ?? ''),
    'email' => (string) ($user['email'] ?? ''),
    'first_name' => $firstName,
    'last_name' => $lastName,
    'name' => $name,
    'roles' => $roles,
    'profile_type' => $profileType ?? 'user_login',
    'is_active' => (bool) ($user['is_active'] ?? true),
    'last_login_at' => $user['last_login_at'] ?? null,
    'created_at' => $user['created_at'] ?? null,
    'updated_at' => $user['updated_at'] ?? null,
], 'Profile retrieved successfully');
