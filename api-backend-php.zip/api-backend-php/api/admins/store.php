<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt): void {
    kcdf_identity_require(in_array('admin_super', kcdf_identity_roles($jwt), true));
    $body = kcdf_identity_body();
    $errors = [];
    if (empty($body['profile_id'])) {
        $errors['profile_id'] = ['The profile_id field is required.'];
    } elseif (!is_numeric($body['profile_id'])) {
        $errors['profile_id'] = ['The profile_id must be a valid integer.'];
    }
    $roles = ['super_admin', 'program_manager', 'accounts', 'readonly'];
    if (empty($body['admin_role'])) {
        $errors['admin_role'] = ['The admin_role field is required.'];
    } elseif (!in_array($body['admin_role'], $roles, true)) {
        $errors['admin_role'] = ['The admin_role must be one of: super_admin, program_manager, accounts, readonly.'];
    }
    kcdf_identity_validation($errors);
    $profileId = (int) $body['profile_id'];
    if (kcdf_identity_profile($database, $profileId) === null) {
        kcdf_identity_error('NOT_FOUND', 'Member profile not found.', 404);
    }
    $admin = kcdf_identity_transaction($database, static function () use ($database, $body, $profileId, $jwt): array {
        if (!kcdf_identity_lock($database, 'member_profiles', $profileId)) {
            throw new RuntimeException('Member profile not found.', 404);
        }
        if (kcdf_identity_exists($database, 'admins', ['profile_id' => $profileId])) {
            throw new RuntimeException('This profile is already registered as an admin.', 409);
        }
        $database->insert('admins', [
            'profile_id' => $profileId,
            'admin_role' => $body['admin_role'],
            'status' => 'active',
        ]);
        $id = (int) $database->id();
        $admin = kcdf_identity_admin($database, $id);
        kcdf_identity_log($database, $jwt, 'create', 'admins', $id, null, $admin);
        return $admin;
    });
    kcdf_identity_success($admin, 'Admin created successfully.', 201);
});
