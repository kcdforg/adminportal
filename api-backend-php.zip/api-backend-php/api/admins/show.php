<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    kcdf_identity_require(in_array('admin_super', kcdf_identity_roles($jwt), true));
    $admin = kcdf_identity_admin($database, $id);
    if ($admin === null) {
        kcdf_identity_error('NOT_FOUND', 'Admin not found.', 404);
    }
    kcdf_identity_success($admin);
});
