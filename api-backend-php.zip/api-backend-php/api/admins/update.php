<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    kcdf_identity_require(in_array('admin_super', kcdf_identity_roles($jwt), true));
    $admin = kcdf_identity_admin($database, $id);
    if ($admin === null) {
        kcdf_identity_error('NOT_FOUND', 'Admin not found.', 404);
    }
    $body = kcdf_identity_body();
    $errors = [];
    if (!empty($body['admin_role']) && !in_array($body['admin_role'], ['super_admin', 'program_manager', 'accounts', 'readonly'], true)) {
        $errors['admin_role'] = ['The admin_role must be one of: super_admin, program_manager, accounts, readonly.'];
    }
    if (!empty($body['status']) && !in_array($body['status'], ['active', 'inactive'], true)) {
        $errors['status'] = ['The status must be one of: active, inactive.'];
    }
    kcdf_identity_validation($errors);
    $updated = kcdf_identity_transaction($database, static function () use ($database, $body, $admin, $jwt, $id): array {
        $update = [];
        foreach (['admin_role', 'status'] as $field) {
            if (array_key_exists($field, $body)) {
                $update[$field] = $body[$field];
            }
        }
        if ($update !== []) {
            $database->update('admins', $update, ['id' => $id]);
        }
        $row = kcdf_identity_admin($database, $id);
        kcdf_identity_log($database, $jwt, 'update', 'admins', $id, $admin, $row);
        return $row;
    });
    kcdf_identity_success($updated, 'Admin updated successfully.');
});
