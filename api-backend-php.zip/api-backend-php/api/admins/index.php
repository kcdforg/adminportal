<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt): void {
    kcdf_identity_require(in_array('admin_super', kcdf_identity_roles($jwt), true));
    $result = kcdf_identity_paginate(
        $database,
        'admins',
        $_GET,
        ['status' => 'status', 'admin_role' => 'admin_role'],
        ['id', 'admin_role', 'created_at']
    );
    foreach ($result['data'] as &$admin) {
        $admin['profile'] = kcdf_identity_profile($database, (int) $admin['profile_id']);
    }
    unset($admin);
    kcdf_identity_response(['success' => true, 'data' => $result['data'], 'meta' => $result['meta']]);
});
