<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/academics.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);

try {
    $result = kcdf_acad_page($database, 'programs', $_GET, ['status' => 'status', 'program_type' => 'program_type'], ['id', 'program_name', 'program_type', 'created_at'], 'created_at');
    kcdf_identity_response(['success' => true, 'data' => $result['data'], 'meta' => $result['meta']]);
} catch (Throwable $exception) {
    kcdf_identity_handle_exception($exception);
}
