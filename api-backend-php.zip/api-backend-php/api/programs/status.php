<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/academics.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    kcdf_identity_require(kcdf_acad_elevated($jwt));
    $old = kcdf_acad_program($database, $id);
    if ($old === null) kcdf_identity_error('NOT_FOUND', 'Program not found.', 404);
    $body = kcdf_identity_body();
    kcdf_identity_validation(kcdf_acad_validate_program($body, 'status'));
    $database->update('programs', ['status' => $body['status']], ['id' => $id]);
    $row = kcdf_acad_program($database, $id);
    kcdf_identity_log($database, $jwt, 'status_change', 'programs', $id, $old, $row);
    kcdf_identity_success($row, 'Program status updated successfully.');
});
