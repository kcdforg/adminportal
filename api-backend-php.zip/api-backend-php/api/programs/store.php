<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/academics.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt): void {
    kcdf_identity_require(kcdf_acad_elevated($jwt));
    $body = kcdf_identity_body();
    kcdf_identity_validation(kcdf_acad_validate_program($body, 'create'));
    $database->insert('programs', [
        'program_name' => $body['program_name'],
        'program_type' => $body['program_type'],
        'description' => $body['description'] ?? null,
        'age_group' => $body['age_group'] ?? null,
        'fee_amount' => (float) $body['fee_amount'],
        'status' => $body['status'] ?? 'active',
    ]);
    $id = (int) $database->id();
    $row = kcdf_acad_program($database, $id);
    kcdf_identity_log($database, $jwt, 'create', 'programs', $id, null, $row);
    kcdf_identity_success($row, 'Program created successfully.', 201);
});
