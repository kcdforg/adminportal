<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/academics.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);

try {
    $program = kcdf_acad_program($database, $id);
    if ($program === null) {
        kcdf_identity_error('NOT_FOUND', 'Program not found.', 404);
    }

    kcdf_identity_success($program);
} catch (Throwable $exception) {
    kcdf_identity_handle_exception($exception);
}
