<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt): void {
    kcdf_identity_require(kcdf_identity_is_elevated_admin($jwt));
    $body = kcdf_identity_body();
    kcdf_identity_validation(kcdf_identity_validation_fields($body, 'trainer'));
    $profileId = (int) $body['profile_id'];
    if (kcdf_identity_profile($database, $profileId) === null) {
        kcdf_identity_error('NOT_FOUND', 'Member profile not found.', 404);
    }
    $trainer = kcdf_identity_transaction($database, static function () use ($database, $body, $profileId, $jwt): array {
        if (!kcdf_identity_lock($database, 'member_profiles', $profileId)) {
            throw new RuntimeException('Member profile not found.', 404);
        }
        if (kcdf_identity_exists($database, 'trainers', ['profile_id' => $profileId])) {
            throw new RuntimeException('This profile is already registered as a trainer.', 409);
        }
        $addressId = !empty($body['address']) ? kcdf_identity_create_address($database, $body['address']) : null;
        $database->insert('trainers', [
            'profile_id' => $profileId,
            'trainer_code' => 'TR-TEMP-' . bin2hex(random_bytes(8)),
            'specialization' => $body['specialization'] ?? null,
            'experience_years' => $body['experience_years'] ?? null,
            'bio' => $body['bio'] ?? null,
            'joined_at' => $body['joined_at'] ?? null,
            'address_id' => $addressId,
            'status' => 'active',
        ]);
        $id = (int) $database->id();
        $database->update('trainers', [
            'trainer_code' => 'TR-' . str_pad((string) $id, 3, '0', STR_PAD_LEFT),
        ], ['id' => $id]);
        $trainer = kcdf_identity_trainer($database, $id);
        kcdf_identity_log($database, $jwt, 'create', 'trainers', $id, null, $trainer);
        return $trainer;
    });
    kcdf_identity_success($trainer, 'Trainer created successfully.', 201);
});
