<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);

try {
    kcdf_identity_require(kcdf_identity_is_admin($jwt));
    $result = kcdf_identity_paginate($database, 'trainers', $_GET, ['status' => 'status'], ['id', 'trainer_code', 'created_at']);

    foreach ($result['data'] as &$trainer) {
        $trainer['profile'] = kcdf_identity_profile($database, (int) $trainer['profile_id']);
        $trainer['address'] = kcdf_identity_address($database, $trainer['address_id']);
        if ($trainer['joined_at'] !== null) {
            $trainer['joined_at'] .= ' 00:00:00';
        }
    }
    unset($trainer);

    kcdf_identity_response(['success' => true, 'data' => $result['data'], 'meta' => $result['meta']]);
} catch (Throwable $exception) {
    kcdf_identity_handle_exception($exception);
}
