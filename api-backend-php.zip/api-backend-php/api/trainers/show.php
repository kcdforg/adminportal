<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    $trainer = kcdf_identity_trainer($database, $id);
    if ($trainer === null) {
        kcdf_identity_error('NOT_FOUND', 'Trainer not found.', 404);
    }
    $isOwn = kcdf_identity_id($jwt) === (int) $trainer['profile_id']
        && in_array('trainer', kcdf_identity_roles($jwt), true);
    kcdf_identity_require(kcdf_identity_is_admin($jwt) || $isOwn);
    kcdf_identity_success($trainer);
});
