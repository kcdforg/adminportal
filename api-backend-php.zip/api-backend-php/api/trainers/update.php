<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    $trainer = kcdf_identity_trainer($database, $id);
    if ($trainer === null) {
        kcdf_identity_error('NOT_FOUND', 'Trainer not found.', 404);
    }
    $ownTrainer = kcdf_identity_id($jwt) === (int) $trainer['profile_id']
        && in_array('trainer', kcdf_identity_roles($jwt), true);
    $elevated = kcdf_identity_is_elevated_admin($jwt);
    kcdf_identity_require($elevated || $ownTrainer);
    $body = kcdf_identity_body();
    if (!$elevated) {
        $body = array_intersect_key($body, array_flip(['bio', 'specialization']));
    }
    kcdf_identity_validation(kcdf_identity_validation_fields($body, 'trainer', true));
    $updated = kcdf_identity_transaction($database, static function () use ($database, $body, $trainer, $jwt, $id): array {
        $addressId = $trainer['address_id'];
        if (!empty($body['address'])) {
            if ($addressId) {
                kcdf_identity_update_address($database, (int) $addressId, $body['address']);
            } else {
                $addressId = kcdf_identity_create_address($database, $body['address']);
                $database->update('trainers', ['address_id' => $addressId], ['id' => $id]);
            }
        }
        $update = [];
        foreach (['specialization', 'experience_years', 'bio', 'joined_at', 'status'] as $field) {
            if (array_key_exists($field, $body)) {
                $update[$field] = $body[$field];
            }
        }
        if ($update !== []) {
            $database->update('trainers', $update, ['id' => $id]);
        }
        $row = kcdf_identity_trainer($database, $id);
        kcdf_identity_log($database, $jwt, 'update', 'trainers', $id, $trainer, $row);
        return $row;
    });
    kcdf_identity_success($updated, 'Trainer updated successfully.');
});
