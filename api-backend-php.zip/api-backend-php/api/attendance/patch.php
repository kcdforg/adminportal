<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/academics.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    $old = kcdf_identity_one($database, 'attendance', ['id' => $id]);
    if ($old === null) kcdf_identity_error('NOT_FOUND', 'Attendance record not found.', 404);
    $session = kcdf_acad_session($database, (int) $old['batch_session_id']);
    if ($session === null || !kcdf_acad_attendance_access($database, $jwt, $session, $session['batch'])) kcdf_identity_error('UNAUTHORIZED', 'You are not authorized to perform this action.', 403);
    if ($session['attendance_locked']) kcdf_identity_error('ATTENDANCE_LOCKED', 'Attendance for this session is locked.', 403);
    $body = kcdf_identity_body();
    $statuses = ['present', 'absent', 'late', 'excused'];
    $errors = [];
    if (!array_key_exists('attendance_status', $body)) $errors['attendance_status'] = ['The attendance_status field is required.'];
    elseif (!in_array($body['attendance_status'], $statuses, true)) $errors['attendance_status'] = ['The attendance_status must be one of: present, absent, late, excused.'];
    kcdf_identity_validation($errors);
    $update = array_intersect_key($body, array_flip(['attendance_status', 'remarks']));
    $update['marked_by_member_id'] = kcdf_identity_actor($jwt);
    $update['marked_at'] = date('Y-m-d H:i:s');
    try {
        kcdf_acad_transaction($database, static function () use ($database, $jwt, $id, $old, $update): void {
            $lockedSession = kcdf_acad_lock_session($database, (int) $old['batch_session_id']);
            if ($lockedSession === null) kcdf_acad_fail('NOT_FOUND', 'Session not found.', 404);
            $batch = kcdf_acad_batch($database, (int) $lockedSession['batch_id'], false);
            if (!kcdf_acad_attendance_access($database, $jwt, $lockedSession, $batch)) {
                kcdf_acad_fail('UNAUTHORIZED', 'You are not authorized to perform this action.', 403);
            }
            if ((bool) $lockedSession['attendance_locked']) kcdf_acad_fail('ATTENDANCE_LOCKED', 'Attendance for this session is locked.', 403);
            $database->update('attendance', $update, ['id' => $id]);
            $row = kcdf_identity_one($database, 'attendance', ['id' => $id]);
            kcdf_identity_log($database, $jwt, 'update', 'attendance', $id, $old, $row);
        });
    } catch (KcdfAcademicsException $exception) {
        kcdf_acad_error($exception);
    }
    $row = kcdf_identity_one($database, 'attendance', ['id' => $id]);
    kcdf_identity_success($row, 'Attendance record updated.');
});
