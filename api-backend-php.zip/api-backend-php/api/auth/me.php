<?php

declare(strict_types=1);

global $routeParams;
$routeParams = $routeParams ?? [];
$_SERVER['ROUTE_PARAMS'] = $routeParams;

$bootstrap = $bootstrap ?? [];
$database = $bootstrap['database'] ?? null;
if (!$database instanceof Medoo\Medoo) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'STARTUP_ERROR',
            'message' => 'The API runtime has not been initialized.',
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

try {
    $payload = authenticate();
} catch (RuntimeException $exception) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'UNAUTHENTICATED',
            'message' => $exception->getMessage(),
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

$profileId = (int) ($payload['profile_id'] ?? 0);
if ($profileId <= 0) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'UNAUTHENTICATED',
            'message' => 'The token is missing profile information.',
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

$user = null;
$roleRows = [];
$profileType = null;

$user = $database->get('user_logins', ['id', 'username', 'email', 'first_name', 'last_name', 'is_active', 'created_at', 'updated_at', 'last_login_at'], ['id' => $profileId]);
if (!$user) {
    $user = $database->get('family_members', ['id', 'name', 'email', 'phone', 'status', 'created_at', 'updated_at'], ['id' => $profileId]);
    $profileType = 'family_member';
}
if (!$user) {
    $user = $database->get('trainers', ['id', 'username', 'email', 'first_name', 'last_name', 'is_active', 'created_at', 'updated_at'], ['id' => $profileId]);
    $profileType = 'trainer';
}
if (!$user) {
    $user = $database->get('admins', ['id', 'username', 'email', 'first_name', 'last_name', 'is_active', 'created_at', 'updated_at'], ['id' => $profileId]);
    $profileType = 'admin';
}

if (!$user) {
    http_response_code(404);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'PROFILE_NOT_FOUND',
            'message' => 'The authenticated profile could not be found.',
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

if (isset($payload['roles']) && is_array($payload['roles'])) {
    $roleRows = array_values(array_unique(array_filter(array_map('strval', $payload['roles']))));
}

$identity = [
    'id' => (int) ($user['id'] ?? 0),
    'username' => (string) ($user['username'] ?? $user['email'] ?? ''),
    'email' => (string) ($user['email'] ?? ''),
    'first_name' => (string) ($user['first_name'] ?? ''),
    'last_name' => (string) ($user['last_name'] ?? ''),
    'name' => trim((string) ($user['name'] ?? '') !== '' ? (string) $user['name'] : ((string) ($user['first_name'] ?? '') . ' ' . (string) ($user['last_name'] ?? ''))),
    'roles' => $roleRows,
    'profile_type' => $profileType ?? 'user_login',
    'is_active' => (bool) ($user['is_active'] ?? true),
    'last_login_at' => $user['last_login_at'] ?? null,
    'created_at' => $user['created_at'] ?? null,
    'updated_at' => $user['updated_at'] ?? null,
];

http_response_code(200);
echo json_encode([
    'success' => true,
    'data' => $identity,
    'message' => 'Profile retrieved successfully',
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
exit;
