<?php

declare(strict_types=1);

global $routeParams;
$routeParams = $routeParams ?? [];
$_SERVER['ROUTE_PARAMS'] = $routeParams;

$bootstrap = $bootstrap ?? [];
$database = $bootstrap['database'] ?? null;
if (!$database instanceof Medoo\Medoo) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'STARTUP_ERROR',
            'message' => 'The API runtime has not been initialized.',
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}
$profileRepository = new \Kcdf\Repositories\ProfileRepository($database);

$body = kcdf_read_json_body();
$username = trim((string) ($body['username'] ?? ''));
$password = (string) ($body['password'] ?? '');

if ($username === '' || $password === '') {
    http_response_code(422);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'VALIDATION_FAILED',
            'message' => 'The given data was invalid.',
            'details' => [
                'username' => $username === '' ? ['The username field is required.'] : [],
                'password' => $password === '' ? ['The password field is required.'] : [],
            ],
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

$loginRecord = $database->get('user_logins', ['id', 'profile_id', 'username', 'password_hash', 'is_active'], ['username' => $username]);

if ($loginRecord === false || !password_verify($password, (string) $loginRecord['password_hash'])) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'UNAUTHENTICATED',
            'message' => 'Invalid credentials.',
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

if ((int) $loginRecord['is_active'] !== 1) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'UNAUTHENTICATED',
            'message' => 'Account is deactivated.',
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

$profileId = (int) $loginRecord['profile_id'];
$profile = $profileRepository->findById($profileId);
if ($profile === null) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'UNAUTHENTICATED',
            'message' => 'The user profile could not be found.',
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

$roleData = $profileRepository->rolesForProfile($profileId);
$accessToken = createToken([
    'profile_id' => $profileId,
    'username' => $username,
    'roles' => $roleData['roles'],
    'family_ids' => $roleData['family_ids'],
], 'access');
$refreshToken = createToken([
    'profile_id' => $profileId,
], 'refresh');

$refreshHash = hash('sha256', $refreshToken);
$refreshExpires = time() + (int) (($bootstrap['config']['jwt']['refresh_ttl'] ?? 2592000));
$database->insert('refresh_tokens', [
    'profile_id' => $profileId,
    'token_hash' => $refreshHash,
    'expires_at' => date('Y-m-d H:i:s', $refreshExpires),
    'created_at' => date('Y-m-d H:i:s'),
]);

$database->update('user_logins', ['last_login_at' => date('Y-m-d H:i:s')], ['id' => (int) $loginRecord['id']]);

$profileSummary = [
    'id' => (int) $profile['id'],
    'first_name' => $profile['first_name'],
    'last_name' => $profile['last_name'],
    'roles' => $roleData['roles'],
    'family_ids' => $roleData['family_ids'],
];

http_response_code(200);
echo json_encode([
    'success' => true,
    'message' => 'Login successful',
    'data' => [
        'access_token' => $accessToken,
        'refresh_token' => $refreshToken,
        'token_type' => 'Bearer',
        'expires_in' => (int) ($bootstrap['config']['jwt']['access_ttl'] ?? 900),
        'profile' => $profileSummary,
    ],
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
exit;
