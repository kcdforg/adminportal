<?php

declare(strict_types=1);

global $routeParams;
$routeParams = $routeParams ?? [];
$_SERVER['ROUTE_PARAMS'] = $routeParams;

$bootstrap = $bootstrap ?? [];
$database = $bootstrap['database'] ?? null;

if (!$database instanceof Medoo\Medoo) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'STARTUP_ERROR',
            'message' => 'The API runtime has not been initialized.',
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}
$profileRepository = new \Kcdf\Repositories\ProfileRepository($database);

$body = kcdf_read_json_body();
$refreshToken = trim((string) ($body['refresh_token'] ?? ''));
if ($refreshToken === '') {
    http_response_code(422);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'VALIDATION_FAILED',
            'message' => 'The given data was invalid.',
            'details' => [
                'refresh_token' => ['The refresh_token field is required.'],
            ],
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

try {
    $claims = authenticate('Bearer ' . $refreshToken, true);
} catch (RuntimeException $exception) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'UNAUTHENTICATED',
            'message' => $exception->getMessage(),
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

if (($claims['type'] ?? 'access') !== 'refresh') {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'UNAUTHENTICATED',
            'message' => 'Invalid or expired refresh token.',
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

$profileId = (int) ($claims['profile_id'] ?? 0);
$tokenHash = hash('sha256', $refreshToken);
$row = $database->get('refresh_tokens', ['id', 'profile_id', 'expires_at'], [
    'token_hash' => $tokenHash,
    'profile_id' => $profileId,
    'revoked_at' => null,
    'expires_at[>]' => date('Y-m-d H:i:s'),
]);

if ($row === false) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'UNAUTHENTICATED',
            'message' => 'Refresh token has been revoked or expired.',
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

try {
    $pdo = $database->pdo;
    $pdo->beginTransaction();
    $database->update('refresh_tokens', ['revoked_at' => date('Y-m-d H:i:s')], ['id' => (int) $row['id'], 'revoked_at' => null]);

    $profile = $profileRepository->findById($profileId);
    if ($profile === null) {
        throw new RuntimeException('Profile not found.');
    }

    $roleData = $profileRepository->rolesForProfile($profileId);
    $newAccessToken = createToken([
        'profile_id' => $profileId,
        'username' => (string) ($claims['username'] ?? $profile['email'] ?? 'user'),
        'roles' => $roleData['roles'],
        'family_ids' => $roleData['family_ids'],
    ], 'access');
    $newRefreshToken = createToken(['profile_id' => $profileId], 'refresh');
    $newHash = hash('sha256', $newRefreshToken);
    $newRefreshExpires = time() + (int) (($bootstrap['config']['jwt']['refresh_ttl'] ?? 2592000));

    $database->insert('refresh_tokens', [
        'profile_id' => $profileId,
        'token_hash' => $newHash,
        'expires_at' => date('Y-m-d H:i:s', $newRefreshExpires),
        'created_at' => date('Y-m-d H:i:s'),
    ]);
    $pdo->commit();

    $profileSummary = [
        'id' => (int) $profile['id'],
        'first_name' => $profile['first_name'],
        'last_name' => $profile['last_name'],
        'roles' => $roleData['roles'],
        'family_ids' => $roleData['family_ids'],
    ];

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'message' => 'Token refreshed',
        'data' => [
            'access_token' => $newAccessToken,
            'refresh_token' => $newRefreshToken,
            'token_type' => 'Bearer',
            'expires_in' => (int) ($bootstrap['config']['jwt']['access_ttl'] ?? 900),
            'profile' => $profileSummary,
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'UNAUTHENTICATED',
            'message' => 'Invalid or expired refresh token.',
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}
