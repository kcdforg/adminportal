<?php

declare(strict_types=1);

global $routeParams;
$routeParams = $routeParams ?? [];
$_SERVER['ROUTE_PARAMS'] = $routeParams;

$bootstrap = $bootstrap ?? [];
$database = $bootstrap['database'] ?? null;
if (!$database instanceof Medoo\Medoo) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'STARTUP_ERROR',
            'message' => 'The API runtime has not been initialized.',
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

try {
    $payload = authenticate();
} catch (RuntimeException $exception) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'UNAUTHENTICATED',
            'message' => $exception->getMessage(),
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

$body = kcdf_read_json_body();
$refreshToken = trim((string) ($body['refresh_token'] ?? ''));
if ($refreshToken === '') {
    http_response_code(422);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'VALIDATION_FAILED',
            'message' => 'The given data was invalid.',
            'details' => [
                'refresh_token' => ['The refresh_token field is required.'],
            ],
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

try {
    $refreshClaims = authenticate('Bearer ' . $refreshToken, true);
    if ((int) ($refreshClaims['profile_id'] ?? 0) !== (int) ($payload['profile_id'] ?? 0)) {
        throw new RuntimeException('Refresh token does not match the current user.', 401);
    }
} catch (RuntimeException $exception) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'UNAUTHENTICATED',
            'message' => $exception->getMessage(),
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

$hash = hash('sha256', $refreshToken);
$database->update('refresh_tokens', ['revoked_at' => date('Y-m-d H:i:s')], [
    'profile_id' => (int) $payload['profile_id'],
    'token_hash' => $hash,
    'revoked_at' => null,
]);

http_response_code(200);
echo json_encode([
    'success' => true,
    'message' => 'Logged out successfully',
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
exit;
