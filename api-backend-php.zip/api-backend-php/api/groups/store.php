<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/community-notifications.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);

try {
    kcdf_community_require_admin($jwt, 'Only admins can create groups.');
    $body = kcdf_identity_body();
    kcdf_identity_validation(kcdf_community_group_validation($body, 'create'));
    $actorId = kcdf_identity_actor($jwt);

    $id = kcdf_community_transaction($database, static function () use ($database, $body, $actorId): int {
        $database->insert('parent_groups', [
            'group_name' => $body['group_name'],
            'description' => !empty($body['description']) ? $body['description'] : null,
            'visibility' => $body['visibility'],
            'status' => 'active',
        ]);
        $groupId = (int) $database->id();
        kcdf_identity_log($database, ['profile_id' => $actorId], 'created', 'parent_groups', $groupId, null, [
            'group_name' => $body['group_name'],
            'visibility' => $body['visibility'],
        ]);
        return $groupId;
    });

    kcdf_identity_success(kcdf_identity_one($database, 'parent_groups', ['id' => $id]), 'Group created successfully.', 201);
} catch (Throwable $exception) {
    kcdf_identity_handle_exception($exception);
}
