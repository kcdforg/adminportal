<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/community-notifications.php';
$groupId = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
$memberId = (int) ($_SERVER['ROUTE_PARAMS']['member_id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $groupId, $memberId): void {
    kcdf_community_require_admin($jwt, 'Only admins can remove or ban group members.');
    $body = kcdf_identity_body();
    kcdf_identity_validation(kcdf_community_group_validation($body, 'member-action'));
    $existing = kcdf_community_member($database, $groupId, $memberId);
    if ($existing === null) {
        kcdf_identity_error('NOT_FOUND', 'Member not found in this group.', 404);
    }
    $action = $body['action'];
    $oldStatus = $existing['status'];
    $newStatus = $action === 'ban' ? 'banned' : 'left';
    $logAction = $action === 'ban' ? 'group_member_banned' : 'group_member_removed';
    kcdf_community_transaction($database, static function () use ($database, $jwt, $groupId, $memberId, $existing, $newStatus, $logAction, $oldStatus): void {
        $database->update('group_members', ['status' => $newStatus], ['id' => $existing['id']]);
        kcdf_identity_log($database, $jwt, $logAction, 'parent_groups', $groupId, ['status' => $oldStatus], ['status' => $newStatus, 'member_id' => $memberId]);
    });
    kcdf_identity_success(null, 'Member action applied successfully.');
});
