<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/community-notifications.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    kcdf_community_require_admin($jwt, 'Only admins can update groups.');
    $old = kcdf_identity_one($database, 'parent_groups', ['id' => $id]);
    if ($old === null) {
        kcdf_identity_error('NOT_FOUND', 'Group not found.', 404);
    }
    $body = kcdf_identity_body();
    kcdf_identity_validation(kcdf_community_group_validation($body, 'update'));
    $updates = array_intersect_key($body, array_flip(['group_name', 'description', 'visibility', 'status']));
    $id = kcdf_community_transaction($database, static function () use ($database, $jwt, $id, $old, $updates): int {
        if ($updates !== []) {
            $database->update('parent_groups', $updates, ['id' => $id]);
        }
        kcdf_identity_log($database, $jwt, 'updated', 'parent_groups', $id, [
            'group_name' => $old['group_name'],
            'visibility' => $old['visibility'],
            'status' => $old['status'],
        ], $updates);
        return $id;
    });
    kcdf_identity_success(kcdf_identity_one($database, 'parent_groups', ['id' => $id]), 'Group updated successfully.');
});
