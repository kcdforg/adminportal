<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/community-notifications.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);

try {
    $where = [];
    if (!kcdf_community_is_admin($jwt)) {
        $profileId = kcdf_identity_id($jwt);
        $memberGroupIds = $profileId > 0
            ? ($database->select('group_members', 'group_id', ['member_id' => $profileId, 'status' => 'active']) ?? [])
            : [];
        $publicIds = $database->select('parent_groups', 'id', ['visibility' => 'public']) ?? [];
        $visibleIds = array_values(array_unique(array_map('intval', array_merge($publicIds, $memberGroupIds))));
        if ($visibleIds === []) {
            $perPage = min(max((int) ($_GET['per_page'] ?? 20), 1), 100);
            kcdf_identity_response(['success' => true, 'data' => [], 'meta' => [
                'total' => 0, 'per_page' => $perPage, 'current_page' => 1, 'last_page' => 1,
            ]]);
        }
        $where['id'] = $visibleIds;
    }

    $result = kcdf_community_paginate($database, 'parent_groups', $_GET, $where, [
        'visibility' => 'visibility',
        'status' => 'status',
    ]);

    kcdf_identity_response(['success' => true, 'data' => $result['data'], 'meta' => $result['meta']]);
} catch (Throwable $exception) {
    kcdf_identity_handle_exception($exception);
}
