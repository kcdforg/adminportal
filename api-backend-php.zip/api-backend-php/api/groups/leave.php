<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/community-notifications.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    $profileId = kcdf_identity_id($jwt);
    $existing = kcdf_community_member($database, $id, $profileId);
    if ($existing === null || $existing['status'] !== 'active') {
        kcdf_identity_error('NOT_FOUND', 'You are not an active member of this group.', 404);
    }
    kcdf_community_transaction($database, static function () use ($database, $jwt, $id, $profileId, $existing): void {
        $database->update('group_members', ['status' => 'left'], ['id' => $existing['id'], 'status' => 'active']);
        kcdf_identity_log($database, $jwt, 'group_left', 'parent_groups', $id, ['status' => 'active'], ['status' => 'left', 'member_id' => $profileId]);
    });
    kcdf_identity_success(null, 'Left group successfully.');
});
