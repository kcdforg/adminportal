<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/community-notifications.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);

try {
    $group = kcdf_identity_one($database, 'parent_groups', ['id' => $id]);
    if ($group === null) {
        kcdf_identity_error('NOT_FOUND', 'Group not found.', 404);
    }

    if (!kcdf_community_group_access($database, $jwt, $group, 'view')) {
        kcdf_identity_error('UNAUTHORIZED', 'You do not have permission to view this group.', 403);
    }

    kcdf_identity_success($group);
} catch (Throwable $exception) {
    kcdf_identity_handle_exception($exception);
}
