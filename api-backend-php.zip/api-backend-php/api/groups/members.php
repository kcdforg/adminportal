<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/community-notifications.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);

try {
    $group = kcdf_identity_one($database, 'parent_groups', ['id' => $id]);
    if ($group === null) {
        kcdf_identity_error('NOT_FOUND', 'Group not found.', 404);
    }

    if (!kcdf_community_group_access($database, $jwt, $group, 'members')) {
        kcdf_identity_error('UNAUTHORIZED', 'You do not have permission to view members of this group.', 403);
    }

    $rows = $database->select('group_members', ['[>]member_profiles' => ['member_id' => 'id']], [
        'group_members.id',
        'group_members.group_id',
        'group_members.member_id',
        'group_members.joined_at',
        'group_members.status',
        'member_profiles.first_name',
        'member_profiles.last_name',
        'member_profiles.mobile',
        'member_profiles.email',
    ], ['group_members.group_id' => $id, 'group_members.status' => 'active']) ?? [];

    $members = [];
    foreach ($rows as $row) {
        $row = kcdf_identity_cast_ids($row);
        $row['member_name'] = trim($row['first_name'] . ' ' . $row['last_name']);
        unset($row['first_name'], $row['last_name']);
        $members[] = $row;
    }

    kcdf_identity_success($members);
} catch (Throwable $exception) {
    kcdf_identity_handle_exception($exception);
}
