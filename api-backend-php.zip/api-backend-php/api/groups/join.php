<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/community-notifications.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    if (!kcdf_community_is_parent($jwt)) {
        kcdf_identity_error('UNAUTHORIZED', 'Only parents can join groups.', 403);
    }
    $profileId = kcdf_identity_id($jwt);
    $actorId = kcdf_identity_actor($jwt);
    try {
        $memberId = kcdf_community_transaction($database, static function () use ($database, $id, $profileId, $actorId): int {
            $pdo = $database->pdo;
            $sql = 'SELECT * FROM parent_groups WHERE id = :id' . ($database->type === 'sqlite' ? '' : ' FOR UPDATE');
            $statement = $pdo->prepare($sql);
            $statement->execute([':id' => $id]);
            $group = $statement->fetch(PDO::FETCH_ASSOC);
            if (!is_array($group)) {
                kcdf_community_fail('NOT_FOUND', 'Group not found.', 404);
            }
            if ($group['status'] === 'archived') {
                kcdf_community_fail('GROUP_ARCHIVED', 'Cannot join an archived group.');
            }
            if ($group['visibility'] !== 'public') {
                kcdf_community_fail('UNAUTHORIZED', 'Only public groups can be joined directly.', 403);
            }
            $existing = kcdf_community_member($database, $id, $profileId);
            if ($existing !== null) {
                if ($existing['status'] === 'banned') {
                    kcdf_community_fail('UNAUTHORIZED', 'You are banned from this group.', 403);
                }
                if ($existing['status'] === 'active') {
                    kcdf_community_fail('ALREADY_MEMBER', 'You are already a member of this group.', 409);
                }
                $database->update('group_members', ['status' => 'active', 'joined_at' => date('Y-m-d H:i:s')], ['id' => $existing['id']]);
                kcdf_identity_log($database, ['profile_id' => $actorId], 'group_joined', 'parent_groups', $id, ['status' => 'left'], ['status' => 'active', 'member_id' => $profileId]);
                return (int) $existing['id'];
            }
            $database->insert('group_members', [
                'group_id' => $id,
                'member_id' => $profileId,
                'joined_at' => date('Y-m-d H:i:s'),
                'status' => 'active',
            ]);
            $newId = (int) $database->id();
            kcdf_identity_log($database, ['profile_id' => $actorId], 'group_joined', 'parent_groups', $id, null, ['member_id' => $profileId]);
            return $newId;
        });
    } catch (KcdfCommunityException $exception) {
        kcdf_community_error($exception);
    } catch (PDOException $exception) {
        if (in_array((string) $exception->getCode(), ['23000', '19'], true)) {
            kcdf_identity_error('ALREADY_MEMBER', 'You are already a member of this group.', 409);
        }
        throw $exception;
    }
    kcdf_identity_success(kcdf_identity_one($database, 'group_members', ['id' => $memberId]), 'Joined group successfully.', 201);
});
