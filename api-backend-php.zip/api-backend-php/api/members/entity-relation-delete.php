<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
$memberId = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
$relationId = (int) ($_SERVER['ROUTE_PARAMS']['relation_id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $memberId, $relationId): void {
    if (kcdf_identity_profile($database, $memberId) === null) {
        kcdf_identity_error('NOT_FOUND', 'Member profile not found.', 404);
    }
    kcdf_identity_require(kcdf_identity_member_access($database, $jwt, $memberId, 'manage_relations'));
    $relation = kcdf_identity_one($database, 'entity_member_relations', [
        'id' => $relationId,
        'member_id' => $memberId,
    ]);
    if ($relation === null) {
        kcdf_identity_error('NOT_FOUND', 'Entity relation not found.', 404);
    }
    kcdf_identity_transaction($database, static function () use ($database, $relation, $relationId, $memberId, $jwt): void {
        $database->update('entity_member_relations', [
            'is_current' => 0,
            'end_date' => date('Y-m-d'),
        ], ['id' => $relationId]);
        kcdf_identity_log($database, $jwt, 'remove_entity_relation', 'member_profiles', $memberId, $relation, [
            'is_current' => false,
            'end_date' => date('Y-m-d'),
        ]);
    });
    kcdf_identity_success(null, 'Entity relation removed successfully.');
});
