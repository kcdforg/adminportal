<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);

try {
    $profile = kcdf_identity_profile($database, $id);
    if ($profile === null) {
        kcdf_identity_error('NOT_FOUND', 'Member profile not found.', 404);
    }

    kcdf_identity_require(kcdf_identity_member_access($database, $jwt, $id, 'view'));
    kcdf_identity_success($profile);
} catch (Throwable $exception) {
    kcdf_identity_handle_exception($exception);
}
