<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    $profile = kcdf_identity_profile($database, $id);
    if ($profile === null) {
        kcdf_identity_error('NOT_FOUND', 'Member profile not found.', 404);
    }
    kcdf_identity_require(kcdf_identity_member_access($database, $jwt, $id, 'edit'));
    $body = kcdf_identity_body();
    $errors = kcdf_identity_validation_fields($body, 'member', true);
    if (!empty($body['email']) && $database->has('member_profiles', [
        'email' => $body['email'],
        'id[!]' => $id,
    ])) {
        $errors['email'] = ['A profile with this email already exists.'];
    }
    kcdf_identity_validation($errors);
    $allowed = ['first_name', 'middle_name', 'last_name', 'date_of_birth', 'gender', 'mobile', 'email', 'photo_url', 'blood_group', 'status'];
    $update = [];
    foreach ($allowed as $field) {
        if (array_key_exists($field, $body)) {
            $update[$field] = $body[$field];
        }
    }
    $updated = kcdf_identity_transaction($database, static function () use ($database, $update, $profile, $jwt, $id): array {
        if ($update !== []) {
            $database->update('member_profiles', $update, ['id' => $id]);
        }
        $row = kcdf_identity_profile($database, $id);
        kcdf_identity_log($database, $jwt, 'update', 'member_profiles', $id, $profile, $row);
        return $row;
    });
    kcdf_identity_success($updated, 'Member profile updated successfully.');
});
