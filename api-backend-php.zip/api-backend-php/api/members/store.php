<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);

try {
    kcdf_identity_require(kcdf_identity_is_elevated_admin($jwt));
    $body = kcdf_identity_body();
    $errors = kcdf_identity_validation_fields($body, 'member');
    if (!empty($body['email']) && kcdf_identity_exists($database, 'member_profiles', ['email' => $body['email']])) {
        $errors['email'] = ['A profile with this email already exists.'];
    }
    kcdf_identity_validation($errors);

    $profile = kcdf_identity_transaction($database, static function () use ($database, $body, $jwt): array {
        $database->insert('member_profiles', [
            'first_name' => $body['first_name'],
            'middle_name' => $body['middle_name'] ?? null,
            'last_name' => $body['last_name'],
            'date_of_birth' => $body['date_of_birth'] ?? null,
            'gender' => $body['gender'] ?? null,
            'mobile' => $body['mobile'] ?? null,
            'email' => $body['email'] ?? null,
            'photo_url' => $body['photo_url'] ?? null,
            'blood_group' => $body['blood_group'] ?? null,
            'status' => 'active',
        ]);
        $id = (int) $database->id();
        $profile = kcdf_identity_profile($database, $id);
        kcdf_identity_log($database, $jwt, 'create', 'member_profiles', $id, null, $profile);
        return $profile;
    });

    kcdf_identity_success($profile, 'Member profile created successfully.', 201);
} catch (Throwable $exception) {
    kcdf_identity_handle_exception($exception);
}
