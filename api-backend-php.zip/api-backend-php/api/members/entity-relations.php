<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
$memberId = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
kcdf_identity_run($database, static function () use ($database, $jwt, $memberId): void {
    if (kcdf_identity_profile($database, $memberId) === null) {
        kcdf_identity_error('NOT_FOUND', 'Member profile not found.', 404);
    }
    kcdf_identity_require(kcdf_identity_member_access($database, $jwt, $memberId, 'view'));
    $relations = kcdf_identity_many($database, 'entity_member_relations', ['*'], [
        'member_id' => $memberId,
        'ORDER' => ['is_current' => 'DESC', 'start_date' => 'DESC'],
    ]);
    foreach ($relations as &$relation) {
        if ($relation['start_date'] !== null) {
            $relation['start_date'] .= ' 00:00:00';
        }
        if ($relation['end_date'] !== null) {
            $relation['end_date'] .= ' 00:00:00';
        }
        $relation['is_current'] = (bool) $relation['is_current'];
        if ($relation['relation_context'] !== null) {
            $relation['relation_context'] = json_decode((string) $relation['relation_context'], true);
        }
        $relation['entity'] = kcdf_identity_entity($database, (int) $relation['entity_id']);
    }
    unset($relation);
    kcdf_identity_success($relations);
});
