<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);

try {
    kcdf_identity_require(kcdf_identity_is_admin($jwt));
    $result = kcdf_identity_paginate(
        $database,
        'member_profiles',
        $_GET,
        ['status' => 'status'],
        ['id', 'first_name', 'last_name', 'created_at'],
        ['first_name', 'last_name', 'email', 'mobile']
    );

    kcdf_identity_response(['success' => true, 'data' => $result['data'], 'meta' => $result['meta']]);
} catch (Throwable $exception) {
    kcdf_identity_handle_exception($exception);
}
