<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/academics.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);

try {
    $session = kcdf_acad_session($database, $id);
    if ($session === null) {
        kcdf_identity_error('NOT_FOUND', 'Session not found.', 404);
    }

    kcdf_identity_require(kcdf_acad_session_access($database, $jwt, $session, $session['batch']));
    kcdf_identity_success($session);
} catch (Throwable $exception) {
    kcdf_identity_handle_exception($exception);
}
