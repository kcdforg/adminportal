<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/academics.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);

try {
    $old = kcdf_acad_session($database, $id);
    if ($old === null) {
        kcdf_identity_error('NOT_FOUND', 'Session not found.', 404);
    }

    kcdf_identity_require(kcdf_acad_session_access($database, $jwt, $old, $old['batch'], 'edit'));
    $body = kcdf_identity_body();
    kcdf_identity_validation(kcdf_acad_validate_session($body, 'update'));

    $allowed = kcdf_acad_elevated($jwt)
        ? ['session_number', 'session_title', 'session_date', 'start_time', 'end_time', 'session_type', 'status', 'trainer_id', 'topics_covered', 'homework', 'notes']
        : ['topics_covered', 'homework', 'notes'];

    $update = array_intersect_key($body, array_flip($allowed));
    foreach (['session_number', 'trainer_id'] as $field) {
        if (array_key_exists($field, $update) && $update[$field] !== null) {
            $update[$field] = (int) $update[$field];
        }
    }

    if ($update !== []) {
        $database->update('batch_sessions', $update, ['id' => $id]);
    }

    $session = kcdf_acad_session($database, $id);
    kcdf_identity_log($database, $jwt, 'update', 'batch_sessions', $id, $old, $session);
    kcdf_identity_success($session, 'Session updated successfully.');
} catch (Throwable $exception) {
    kcdf_identity_handle_exception($exception);
}
