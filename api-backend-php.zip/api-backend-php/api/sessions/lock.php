<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/academics.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    kcdf_identity_require(kcdf_acad_elevated($jwt));
    try {
        kcdf_acad_transaction($database, static function () use ($database, $jwt, $id): void {
            $raw = kcdf_acad_lock_session($database, $id);
            if ($raw === null) kcdf_acad_fail('NOT_FOUND', 'Session not found.', 404);
            if ((bool) $raw['attendance_locked']) kcdf_acad_fail('ALREADY_LOCKED', 'Session attendance is already locked.');
            $old = kcdf_acad_session($database, $id);
            $database->update('batch_sessions', ['attendance_locked' => 1], ['id' => $id]);
            $session = kcdf_acad_session($database, $id);
            kcdf_identity_log($database, $jwt, 'lock', 'batch_sessions', $id, $old, $session);
        });
    } catch (KcdfAcademicsException $exception) {
        kcdf_acad_error($exception);
    }
    $session = kcdf_acad_session($database, $id);
    kcdf_identity_success($session, 'Session attendance locked.');
});
