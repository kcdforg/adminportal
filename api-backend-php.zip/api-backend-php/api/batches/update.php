<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/academics.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    kcdf_identity_require(kcdf_acad_elevated($jwt));
    $old = kcdf_acad_batch($database, $id, false);
    if ($old === null) kcdf_identity_error('NOT_FOUND', 'Batch not found.', 404);
    $body = kcdf_identity_body();
    kcdf_identity_validation(kcdf_acad_validate_batch($body, 'update'));
    if (!empty($body['trainer_id']) && !kcdf_identity_exists($database, 'trainers', ['id' => (int) $body['trainer_id']])) kcdf_identity_error('NOT_FOUND', 'Trainer not found.', 404);
    $update = array_intersect_key($body, array_flip(['batch_name', 'capacity', 'trainer_id', 'start_date', 'end_date', 'status']));
    if (array_key_exists('capacity', $update) && $update['capacity'] !== null) $update['capacity'] = (int) $update['capacity'];
    if (array_key_exists('trainer_id', $update)) $update['trainer_id'] = $update['trainer_id'] === null ? null : (int) $update['trainer_id'];
    if ($update !== []) $database->update('student_batches', $update, ['id' => $id]);
    $batch = kcdf_acad_batch($database, $id);
    kcdf_identity_log($database, $jwt, 'update', 'student_batches', $id, $old, $batch);
    kcdf_identity_success($batch, 'Batch updated successfully.');
});
