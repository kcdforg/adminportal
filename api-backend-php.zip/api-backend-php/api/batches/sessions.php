<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/academics.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    $batch = kcdf_acad_batch($database, $id, false);
    if ($batch === null) kcdf_identity_error('NOT_FOUND', 'Batch not found.', 404);
    kcdf_identity_require(kcdf_acad_batch_access($database, $jwt, $batch));
    $where = ['batch_id' => $id];
    if (!empty($_GET['status'])) $where['status'] = $_GET['status'];
    if (!empty($_GET['session_date_from'])) $where['session_date[>=]'] = $_GET['session_date_from'];
    if (!empty($_GET['session_date_to'])) $where['session_date[<=]'] = $_GET['session_date_to'];
    $total = (int) $database->count('batch_sessions', $where);
    $perPage = min(max((int) ($_GET['per_page'] ?? 20), 1), 100);
    $page = max((int) ($_GET['page'] ?? 1), 1);
    $rows = $database->select('batch_sessions', '*', array_merge($where, [
        'ORDER' => ['session_date' => 'ASC', 'session_number' => 'ASC'],
        'LIMIT' => [($page - 1) * $perPage, $perPage],
    ])) ?? [];
    $data = [];
    foreach ($rows as $row) $data[] = kcdf_acad_session($database, (int) $row['id']);
    kcdf_identity_response(['success' => true, 'data' => $data, 'meta' => [
        'total' => $total, 'per_page' => $perPage, 'current_page' => $page, 'last_page' => max(1, (int) ceil($total / $perPage)),
    ]]);
});
