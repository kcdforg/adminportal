<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/academics.php';
$batchId = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $batchId): void {
    kcdf_identity_require(kcdf_acad_elevated($jwt));
    $batch = kcdf_acad_batch($database, $batchId, false);
    if ($batch === null) kcdf_identity_error('NOT_FOUND', 'Batch not found.', 404);
    $body = kcdf_identity_body();
    kcdf_identity_validation(kcdf_acad_validate_session($body, 'create'));
    $trainerId = array_key_exists('trainer_id', $body) && $body['trainer_id'] !== null
        ? (int) $body['trainer_id'] : ($batch['trainer_id'] === null ? null : (int) $batch['trainer_id']);
    $database->insert('batch_sessions', [
        'batch_id' => $batchId,
        'session_number' => isset($body['session_number']) ? (int) $body['session_number'] : null,
        'session_title' => $body['session_title'] ?? null,
        'session_date' => $body['session_date'],
        'start_time' => $body['start_time'] ?? null,
        'end_time' => $body['end_time'] ?? null,
        'session_type' => $body['session_type'],
        'status' => $body['status'] ?? 'scheduled',
        'trainer_id' => $trainerId,
    ]);
    $id = (int) $database->id();
    $session = kcdf_acad_session($database, $id);
    kcdf_identity_log($database, $jwt, 'create', 'batch_sessions', $id, null, $session);
    kcdf_identity_success($session, 'Session created successfully.', 201);
});
