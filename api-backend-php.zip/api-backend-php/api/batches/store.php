<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/academics.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt): void {
    kcdf_identity_require(kcdf_acad_elevated($jwt));
    $body = kcdf_identity_body();
    kcdf_identity_validation(kcdf_acad_validate_batch($body, 'create'));
    $programId = (int) $body['program_id'];
    if (!kcdf_identity_exists($database, 'programs', ['id' => $programId])) kcdf_identity_error('NOT_FOUND', 'Program not found.', 404);
    if (!empty($body['trainer_id']) && !kcdf_identity_exists($database, 'trainers', ['id' => (int) $body['trainer_id']])) kcdf_identity_error('NOT_FOUND', 'Trainer not found.', 404);
    $database->insert('student_batches', [
        'program_id' => $programId,
        'batch_name' => $body['batch_name'],
        'capacity' => isset($body['capacity']) ? (int) $body['capacity'] : null,
        'trainer_id' => !empty($body['trainer_id']) ? (int) $body['trainer_id'] : null,
        'start_date' => $body['start_date'] ?? null,
        'end_date' => $body['end_date'] ?? null,
        'status' => $body['status'] ?? 'upcoming',
    ]);
    $id = (int) $database->id();
    $batch = kcdf_acad_batch($database, $id);
    kcdf_identity_log($database, $jwt, 'create', 'student_batches', $id, null, $batch);
    kcdf_identity_success($batch, 'Batch created successfully.', 201);
});
