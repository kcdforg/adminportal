<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/academics.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);

try {
    $where = [];
    if (kcdf_identity_is_admin($jwt)) {
        // Administrators can filter across all batches.
    } elseif (kcdf_acad_is_trainer($jwt)) {
        $trainerId = kcdf_acad_trainer_id($database, $jwt);
        if ($trainerId === null) {
            $result = kcdf_acad_empty_page($_GET);
            kcdf_identity_response(['success' => true, 'data' => [], 'meta' => $result['meta']]);
        }
        $where['trainer_id'] = $trainerId;
    } else {
        $batchIds = $database->select('enrollments', 'batch_id', [
            'member_id' => kcdf_identity_id($jwt),
            'status' => ['active', 'pending'],
        ]) ?? [];
        if ($batchIds === []) {
            $result = kcdf_acad_empty_page($_GET);
            kcdf_identity_response(['success' => true, 'data' => [], 'meta' => $result['meta']]);
        }
        $where['id'] = array_values(array_unique(array_map('intval', $batchIds)));
    }

    $result = kcdf_acad_page($database, 'student_batches', $_GET, ['status' => 'status', 'program_id' => 'program_id', 'trainer_id' => 'trainer_id'], ['id', 'batch_name', 'start_date', 'created_at'], 'created_at', $where);
    foreach ($result['data'] as &$batch) {
        $batch = kcdf_acad_batch($database, (int) $batch['id']);
    }
    unset($batch);

    kcdf_identity_response(['success' => true, 'data' => $result['data'], 'meta' => $result['meta']]);
} catch (Throwable $exception) {
    kcdf_identity_handle_exception($exception);
}
