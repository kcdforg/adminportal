<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/academics.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);

try {
    $batch = kcdf_acad_batch($database, $id);
    if ($batch === null) {
        kcdf_identity_error('NOT_FOUND', 'Batch not found.', 404);
    }

    kcdf_identity_require(kcdf_acad_batch_access($database, $jwt, $batch));
    kcdf_identity_success($batch);
} catch (Throwable $exception) {
    kcdf_identity_handle_exception($exception);
}
