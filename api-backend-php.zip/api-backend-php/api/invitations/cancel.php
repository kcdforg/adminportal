<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/community-notifications.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    $invitation = kcdf_identity_one($database, 'invitations', ['id' => $id]);
    if ($invitation === null) {
        kcdf_identity_error('NOT_FOUND', 'Invitation not found.', 404);
    }
    if (!kcdf_community_is_admin($jwt) && kcdf_identity_id($jwt) !== (int) $invitation['invited_by_member_id']) {
        kcdf_identity_error('UNAUTHORIZED', 'You do not have permission to cancel this invitation.', 403);
    }
    try {
        kcdf_community_transaction($database, static function () use ($database, $jwt, $id): void {
            $pdo = $database->pdo;
            $statement = $pdo->prepare('SELECT * FROM invitations WHERE id = :id' . ($database->type === 'sqlite' ? '' : ' FOR UPDATE'));
            $statement->execute([':id' => $id]);
            $row = $statement->fetch(PDO::FETCH_ASSOC);
            if (!is_array($row)) kcdf_community_fail('NOT_FOUND', 'Invitation not found.', 404);
            if (!kcdf_community_is_admin($jwt) && kcdf_identity_id($jwt) !== (int) $row['invited_by_member_id']) {
                kcdf_community_fail('UNAUTHORIZED', 'You do not have permission to cancel this invitation.', 403);
            }
            if ($row['status'] !== 'pending') {
                kcdf_community_fail('INVITATION_NOT_PENDING', 'Only pending invitations can be cancelled.');
            }
            $database->update('invitations', ['status' => 'cancelled'], ['id' => $id, 'status' => 'pending']);
            kcdf_identity_log($database, $jwt, 'status_changed', 'invitations', $id, ['status' => 'pending'], ['status' => 'cancelled']);
        });
    } catch (KcdfCommunityException $exception) {
        kcdf_community_error($exception);
    }
    kcdf_identity_success(null, 'Invitation cancelled successfully.');
});
