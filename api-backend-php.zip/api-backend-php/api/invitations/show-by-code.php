<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/community-notifications.php';
$code = (string) ($_SERVER['ROUTE_PARAMS']['code'] ?? '');
if (!preg_match('/^[A-Za-z0-9]{12,50}$/', $code)) {
    kcdf_identity_error('NOT_FOUND', 'Invitation not found.', 404);
}
$database = $bootstrap['database'] ?? null;
if (!$database instanceof Medoo\Medoo) {
    kcdf_identity_error('STARTUP_ERROR', 'The API runtime has not been initialized.', 500);
}
kcdf_identity_run($database, static function () use ($database, $code): void {
    $invitation = kcdf_identity_one($database, 'invitations', ['invite_code' => $code]);
    if ($invitation === null) {
        kcdf_identity_error('NOT_FOUND', 'Invitation not found.', 404);
    }
    if ($invitation['status'] === 'accepted') {
        kcdf_identity_error('INVITATION_ALREADY_ACCEPTED', 'This invitation has already been accepted.', 422);
    }
    if ($invitation['status'] === 'cancelled') {
        kcdf_identity_error('INVITATION_CANCELLED', 'This invitation has been cancelled.', 422);
    }
    if ($invitation['status'] === 'expired' || kcdf_community_invitation_expired((string) $invitation['sent_at'])) {
        if ($invitation['status'] !== 'expired') {
            $database->update('invitations', ['status' => 'expired'], ['id' => $invitation['id'], 'status' => 'pending']);
        }
        kcdf_identity_error('INVALID_INVITE_CODE', 'This invitation has expired.', 422);
    }
    $inviter = kcdf_identity_profile($database, (int) $invitation['invited_by_member_id']);
    $name = $inviter === null ? 'Unknown' : trim($inviter['first_name'] . ' ' . $inviter['last_name']);
    $expiresAt = gmdate('Y-m-d\TH:i:s\Z', strtotime((string) $invitation['sent_at']) + (7 * 24 * 3600));
    kcdf_identity_success([
        'invite_code' => $invitation['invite_code'],
        'invited_by' => $name,
        'status' => $invitation['status'],
        'expires_at' => $expiresAt,
    ]);
});
