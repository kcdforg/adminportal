<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/community-notifications.php';
$code = (string) ($_SERVER['ROUTE_PARAMS']['code'] ?? '');
if (!preg_match('/^[A-Za-z0-9]{12,50}$/', $code)) {
    kcdf_identity_error('NOT_FOUND', 'Invitation not found.', 404);
}
$database = $bootstrap['database'] ?? null;
if (!$database instanceof Medoo\Medoo) {
    kcdf_identity_error('STARTUP_ERROR', 'The API runtime has not been initialized.', 500);
}
kcdf_identity_run($database, static function () use ($database, $bootstrap, $code): void {
    $current = kcdf_identity_one($database, 'invitations', ['invite_code' => $code]);
    if ($current === null) {
        kcdf_identity_error('NOT_FOUND', 'Invitation not found.', 404);
    }
    if (($current['status'] ?? null) !== 'pending') {
        kcdf_identity_error('INVITATION_NOT_PENDING', 'This invitation cannot be accepted.', 422);
    }
    if (kcdf_community_invitation_expired((string) $current['sent_at'])) {
        $database->update('invitations', ['status' => 'expired'], ['id' => $current['id'], 'status' => 'pending']);
        kcdf_identity_error('INVALID_INVITE_CODE', 'This invitation has expired.', 422);
    }
    $body = kcdf_identity_body();
    kcdf_identity_validation(kcdf_community_invitation_validation($body, 'accept'));
    $email = (string) $body['email'];
    $now = date('Y-m-d H:i:s');
    try {
        $result = kcdf_community_transaction($database, static function (PDO $pdo) use ($database, $bootstrap, $code, $body, $email, $now): array {
            $invitation = kcdf_community_lock_invitation($database, $code);
            if ($invitation === null) {
                kcdf_community_fail('NOT_FOUND', 'Invitation not found.', 404);
            }
            kcdf_community_assert_invitation_pending($invitation);
            if (kcdf_community_invitation_expired((string) $invitation['sent_at'])) {
                $database->update('invitations', ['status' => 'expired'], ['id' => $invitation['id'], 'status' => 'pending']);
                return ['expired' => true];
            }
            $usernameQuery = $pdo->prepare('SELECT id FROM user_logins WHERE username = :username');
            $usernameQuery->execute([':username' => $email]);
            if ($usernameQuery->fetchColumn() !== false) {
                kcdf_community_fail('ACCOUNT_EXISTS', 'An account with this email already exists.', 409);
            }
            $insertProfile = $pdo->prepare(
                'INSERT INTO member_profiles (first_name, last_name, mobile, email, status) ' .
                "VALUES (:first_name, :last_name, :mobile, :email, 'active')"
            );
            $insertProfile->execute([
                ':first_name' => (string) $body['first_name'],
                ':last_name' => (string) $body['last_name'],
                ':mobile' => (string) $body['mobile'],
                ':email' => $email,
            ]);
            $profileId = (int) $pdo->lastInsertId();
            $insertLogin = $pdo->prepare(
                'INSERT INTO user_logins (profile_id, username, password_hash, is_active) ' .
                'VALUES (:profile_id, :username, :password_hash, 1)'
            );
            $insertLogin->execute([
                ':profile_id' => $profileId,
                ':username' => $email,
                ':password_hash' => password_hash((string) $body['password'], PASSWORD_BCRYPT),
            ]);
            $updateInvitation = $pdo->prepare(
                "UPDATE invitations SET status = 'accepted', accepted_at = :accepted_at WHERE id = :id AND status = 'pending'"
            );
            $updateInvitation->execute([':accepted_at' => $now, ':id' => $invitation['id']]);
            if ($updateInvitation->rowCount() !== 1) {
                kcdf_community_fail('INVITATION_NOT_PENDING', 'This invitation cannot be accepted.');
            }
            kcdf_identity_log($database, ['profile_id' => $profileId], 'invitation_accepted', 'invitations', (int) $invitation['id'], ['status' => 'pending'], [
                'status' => 'accepted',
                'new_profile_id' => $profileId,
            ]);
            $tokens = kcdf_community_issue_invitation_tokens($database, $bootstrap, $profileId, $email);
            return ['expired' => false, 'tokens' => $tokens];
        });
    } catch (KcdfCommunityException $exception) {
        kcdf_community_error($exception);
    } catch (PDOException $exception) {
        if (in_array((string) $exception->getCode(), ['23000', '19'], true)) {
            kcdf_identity_error('ACCOUNT_EXISTS', 'An account with this email already exists.', 409);
        }
        throw $exception;
    }
    if ($result['expired']) {
        kcdf_identity_error('INVALID_INVITE_CODE', 'This invitation has expired.', 422);
    }
    kcdf_identity_success($result['tokens'], 'Invitation accepted. Account created successfully.');
});
