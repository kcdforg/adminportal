<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/community-notifications.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt): void {
    $where = [];
    if (!kcdf_community_is_admin($jwt)) {
        $where['invited_by_member_id'] = kcdf_identity_id($jwt);
    }
    $result = kcdf_community_paginate($database, 'invitations', $_GET, $where, ['status' => 'status'], 'sent_at');
    kcdf_identity_response(['success' => true, 'data' => $result['data'], 'meta' => $result['meta']]);
});
