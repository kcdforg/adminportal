<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/community-notifications.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt): void {
    if (!kcdf_community_is_parent($jwt) && !kcdf_community_is_admin($jwt)) {
        kcdf_identity_error('UNAUTHORIZED', 'You do not have permission to send invitations.', 403);
    }
    $body = kcdf_identity_body();
    kcdf_identity_validation(kcdf_community_invitation_validation($body, 'create'));
    $profileId = kcdf_identity_id($jwt);
    if (kcdf_community_invitation_duplicate(
        $database,
        $profileId,
        !empty($body['invite_mobile']) ? (string) $body['invite_mobile'] : null,
        !empty($body['invite_email']) ? (string) $body['invite_email'] : null
    )) {
        kcdf_identity_error('DUPLICATE_INVITATION', 'An active invitation has already been sent to this contact.', 409);
    }
    $code = kcdf_community_generate_invite_code($database);
    try {
        $id = kcdf_community_transaction($database, static function () use ($database, $jwt, $body, $profileId, $code): int {
            $database->insert('invitations', [
                'invited_by_member_id' => $profileId,
                'invite_mobile' => !empty($body['invite_mobile']) ? $body['invite_mobile'] : null,
                'invite_email' => !empty($body['invite_email']) ? $body['invite_email'] : null,
                'invite_code' => $code,
                'status' => 'pending',
                'sent_at' => date('Y-m-d H:i:s'),
            ]);
            $id = (int) $database->id();
            kcdf_identity_log($database, $jwt, 'created', 'invitations', $id, null, ['status' => 'pending']);
            return $id;
        });
    } catch (PDOException $exception) {
        if (in_array((string) $exception->getCode(), ['23000', '19'], true)) {
            kcdf_identity_error('DUPLICATE_INVITATION', 'An active invitation has already been sent to this contact.', 409);
        }
        throw $exception;
    }
    kcdf_identity_success(kcdf_identity_one($database, 'invitations', ['id' => $id]), 'Invitation sent successfully.', 201);
});
