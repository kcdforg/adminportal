<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/community-notifications.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    $where = ['id' => $id, 'member_id' => kcdf_identity_id($jwt)];
    $notification = kcdf_community_notification_for_member($database, $id, kcdf_identity_id($jwt));
    if ($notification === null) {
        kcdf_identity_error('NOT_FOUND', 'Notification not found.', 404);
    }
    if ($notification['status'] !== 'archived') {
        $database->update('notifications', ['status' => 'archived'], $where);
    }
    kcdf_identity_success(kcdf_community_notification_for_member($database, $id, kcdf_identity_id($jwt)), 'Notification archived.');
});
