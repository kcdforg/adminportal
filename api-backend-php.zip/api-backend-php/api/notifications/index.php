<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/community-notifications.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt): void {
    $result = kcdf_community_paginate($database, 'notifications', $_GET, [
        'member_id' => kcdf_identity_id($jwt),
    ], ['status' => 'status', 'type' => 'type']);
    kcdf_identity_response(['success' => true, 'data' => $result['data'], 'meta' => $result['meta']]);
});
