<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/community-notifications.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt): void {
    if (!kcdf_identity_is_elevated_admin($jwt)) {
        kcdf_identity_error('UNAUTHORIZED', 'Only admins can broadcast notifications.', 403);
    }
    $body = kcdf_identity_body();
    kcdf_identity_validation(kcdf_community_notification_validation($body, 'broadcast'));
    $memberIds = match ($body['target_type']) {
        'batch' => $database->select('batch_members', 'member_id', [
            'batch_id' => (int) $body['target_id'],
            'status' => 'active',
        ]) ?? [],
        'group' => $database->select('group_members', 'member_id', [
            'group_id' => (int) $body['target_id'],
            'status' => 'active',
        ]) ?? [],
        'all_families' => $database->select('family_members', 'profile_id', ['status' => 'active']) ?? [],
        default => [],
    };
    $memberIds = array_values(array_unique(array_map('intval', $memberIds)));
    $count = count($memberIds);
    if ($count > 0) {
        kcdf_community_transaction($database, static function () use ($database, $jwt, $body, $memberIds, $count): void {
            $now = date('Y-m-d H:i:s');
            foreach ($memberIds as $memberId) {
                $database->insert('notifications', [
                    'member_id' => $memberId,
                    'title' => $body['title'],
                    'message' => $body['message'],
                    'type' => $body['type'],
                    'status' => 'unread',
                    'created_at' => $now,
                ]);
            }
            kcdf_identity_log($database, $jwt, 'notification_broadcast', 'notifications', 0, null, [
                'target_type' => $body['target_type'],
                'target_id' => !empty($body['target_id']) ? (int) $body['target_id'] : null,
                'title' => $body['title'],
                'type' => $body['type'],
                'count' => $count,
            ]);
        });
    }
    kcdf_identity_success(['sent_to' => $count], 'Notification broadcast successfully.');
});
