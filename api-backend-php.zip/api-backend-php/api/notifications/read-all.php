<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/community-notifications.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt): void {
    $database->update('notifications', [
        'status' => 'read',
        'read_at' => date('Y-m-d H:i:s'),
    ], ['member_id' => kcdf_identity_id($jwt), 'status' => 'unread']);
    $count = (int) $database->rowCount();
    kcdf_identity_success(['updated' => $count], 'All notifications marked as read.');
});
