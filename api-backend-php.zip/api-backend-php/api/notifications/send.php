<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/community-notifications.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt): void {
    if (!kcdf_identity_is_elevated_admin($jwt)) {
        kcdf_identity_error('UNAUTHORIZED', 'Only admins can send notifications.', 403);
    }
    $body = kcdf_identity_body();
    kcdf_identity_validation(kcdf_community_notification_validation($body, 'send'));
    $memberIds = array_map('intval', $body['member_ids']);
    $count = count($memberIds);
    kcdf_community_transaction($database, static function () use ($database, $jwt, $body, $memberIds, $count): void {
        $now = date('Y-m-d H:i:s');
        foreach ($memberIds as $memberId) {
            $database->insert('notifications', [
                'member_id' => $memberId,
                'title' => $body['title'],
                'message' => $body['message'],
                'type' => $body['type'],
                'status' => 'unread',
                'created_at' => $now,
            ]);
        }
        kcdf_identity_log($database, $jwt, 'notification_sent', 'notifications', 0, null, [
            'count' => $count,
            'title' => $body['title'],
            'type' => $body['type'],
        ]);
    });
    kcdf_identity_success(['sent_to' => $count], 'Notifications sent successfully.');
});
