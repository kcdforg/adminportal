<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    kcdf_identity_require(kcdf_identity_is_elevated_admin($jwt));
    $entity = kcdf_identity_entity($database, $id);
    if ($entity === null) {
        kcdf_identity_error('NOT_FOUND', 'Entity not found.', 404);
    }
    $body = kcdf_identity_body();
    kcdf_identity_validation(kcdf_identity_validation_fields($body, 'entity', true));
    $updated = kcdf_identity_transaction($database, static function () use ($database, $body, $entity, $jwt, $id): array {
        $update = [];
        foreach (['entity_type', 'name', 'city', 'state', 'country', 'meta', 'status'] as $field) {
            if (array_key_exists($field, $body)) {
                $update[$field] = $field === 'meta' && is_array($body[$field])
                    ? json_encode($body[$field], JSON_THROW_ON_ERROR)
                    : $body[$field];
            }
        }
        if ($update !== []) {
            $database->update('entities', $update, ['id' => $id]);
        }
        $row = kcdf_identity_entity($database, $id);
        kcdf_identity_log($database, $jwt, 'update', 'entities', $id, $entity, $row);
        return $row;
    });
    kcdf_identity_success($updated, 'Entity updated successfully.');
});
