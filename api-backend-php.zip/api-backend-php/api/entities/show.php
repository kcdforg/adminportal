<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    $entity = kcdf_identity_entity($database, $id);
    if ($entity === null || ($entity['status'] !== 'active' && !kcdf_identity_is_admin($jwt))) {
        kcdf_identity_error('NOT_FOUND', 'Entity not found.', 404);
    }
    kcdf_identity_success($entity);
});
