<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt): void {
    kcdf_identity_require(kcdf_identity_is_elevated_admin($jwt));
    $body = kcdf_identity_body();
    kcdf_identity_validation(kcdf_identity_validation_fields($body, 'entity'));
    $entity = kcdf_identity_transaction($database, static function () use ($database, $body, $jwt): array {
        $database->insert('entities', [
            'entity_type' => $body['entity_type'],
            'name' => $body['name'],
            'city' => $body['city'] ?? null,
            'state' => $body['state'] ?? null,
            'country' => $body['country'] ?? 'India',
            'meta' => !empty($body['meta']) ? json_encode($body['meta'], JSON_THROW_ON_ERROR) : null,
            'status' => 'active',
        ]);
        $id = (int) $database->id();
        $entity = kcdf_identity_entity($database, $id);
        kcdf_identity_log($database, $jwt, 'create', 'entities', $id, null, $entity);
        return $entity;
    });
    kcdf_identity_success($entity, 'Entity created successfully.', 201);
});
