<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt): void {
    $filters = $_GET;
    if (!kcdf_identity_is_admin($jwt)) {
        $filters['status'] = 'active';
    }
    $result = kcdf_identity_paginate(
        $database,
        'entities',
        $filters,
        ['entity_type' => 'entity_type', 'status' => 'status'],
        ['id', 'name', 'entity_type', 'created_at'],
        ['name']
    );
    foreach ($result['data'] as &$entity) {
        if ($entity['meta'] !== null) {
            $entity['meta'] = json_decode((string) $entity['meta'], true);
        }
    }
    unset($entity);
    kcdf_identity_response(['success' => true, 'data' => $result['data'], 'meta' => $result['meta']]);
});
