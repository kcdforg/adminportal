<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);

try {
    kcdf_identity_require(kcdf_identity_is_admin($jwt));
    $result = kcdf_identity_paginate(
        $database,
        'families',
        $_GET,
        ['status' => 'status'],
        ['id', 'family_name', 'family_code', 'created_at'],
        ['family_name']
    );

    foreach ($result['data'] as &$family) {
        $family['address'] = kcdf_identity_address($database, $family['address_id']);
    }
    unset($family);

    kcdf_identity_response(['success' => true, 'data' => $result['data'], 'meta' => $result['meta']]);
} catch (Throwable $exception) {
    kcdf_identity_handle_exception($exception);
}
