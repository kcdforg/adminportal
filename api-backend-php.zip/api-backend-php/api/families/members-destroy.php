<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
$familyId = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
$profileId = (int) ($_SERVER['ROUTE_PARAMS']['profile_id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $familyId, $profileId): void {
    if (!kcdf_identity_exists($database, 'families', ['id' => $familyId])) {
        kcdf_identity_error('NOT_FOUND', 'Family not found.', 404);
    }
    kcdf_identity_require(kcdf_identity_family_access($database, $jwt, $familyId, 'edit'));
    $membership = kcdf_identity_membership($database, $familyId, $profileId);
    if ($membership === null) {
        kcdf_identity_error('NOT_FOUND', 'Member is not part of this family.', 404);
    }
    kcdf_identity_transaction($database, static function () use ($database, $membership, $familyId, $jwt): void {
        $database->update('family_members', ['status' => 'removed'], ['id' => $membership['id']]);
        kcdf_identity_log($database, $jwt, 'remove_member', 'families', $familyId, $membership, ['status' => 'removed']);
    });
    kcdf_identity_success(null, 'Member removed from family successfully.');
});
