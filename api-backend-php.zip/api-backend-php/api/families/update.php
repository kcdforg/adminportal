<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);

try {
    $family = kcdf_identity_family($database, $id);
    if ($family === null) {
        kcdf_identity_error('NOT_FOUND', 'Family not found.', 404);
    }

    kcdf_identity_require(kcdf_identity_family_access($database, $jwt, $id, 'edit'));
    $body = kcdf_identity_body();
    kcdf_identity_validation(kcdf_identity_validation_fields($body, 'family', true));

    $updated = kcdf_identity_transaction($database, static function () use ($database, $body, $family, $jwt, $id): array {
        $addressId = $family['address_id'];
        if (!empty($body['address'])) {
            if ($addressId) {
                kcdf_identity_update_address($database, (int) $addressId, $body['address']);
            } else {
                $addressId = kcdf_identity_create_address($database, $body['address']);
                $database->update('families', ['address_id' => $addressId], ['id' => $id]);
            }
        }

        $update = [];
        foreach (['family_name', 'status'] as $field) {
            if (array_key_exists($field, $body)) {
                $update[$field] = $body[$field];
            }
        }

        if ($update !== []) {
            $database->update('families', $update, ['id' => $id]);
        }

        $row = kcdf_identity_family($database, $id);
        kcdf_identity_log($database, $jwt, 'update', 'families', $id, $family, $row);
        return $row;
    });

    kcdf_identity_success($updated, 'Family updated successfully.');
} catch (Throwable $exception) {
    kcdf_identity_handle_exception($exception);
}
