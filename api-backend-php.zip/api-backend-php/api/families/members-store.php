<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
$familyId = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $familyId): void {
    if (!kcdf_identity_exists($database, 'families', ['id' => $familyId])) {
        kcdf_identity_error('NOT_FOUND', 'Family not found.', 404);
    }
    kcdf_identity_require(kcdf_identity_family_access($database, $jwt, $familyId, 'edit'));
    $body = kcdf_identity_body();
    $errors = [];
    if (empty($body['profile_id'])) {
        $errors['profile_id'] = ['The profile_id field is required.'];
    } elseif (!is_numeric($body['profile_id'])) {
        $errors['profile_id'] = ['The profile_id must be a valid integer.'];
    }
    $relationships = ['father', 'mother', 'guardian', 'child'];
    if (empty($body['relationship_type'])) {
        $errors['relationship_type'] = ['The relationship_type field is required.'];
    } elseif (!in_array($body['relationship_type'], $relationships, true)) {
        $errors['relationship_type'] = ['The relationship_type must be one of: father, mother, guardian, child.'];
    }
    $roles = ['primary', 'normal', 'student'];
    if (empty($body['member_role'])) {
        $errors['member_role'] = ['The member_role field is required.'];
    } elseif (!in_array($body['member_role'], $roles, true)) {
        $errors['member_role'] = ['The member_role must be one of: primary, normal, student.'];
    }
    kcdf_identity_validation($errors);
    $profileId = (int) $body['profile_id'];
    if (kcdf_identity_profile($database, $profileId) === null) {
        kcdf_identity_error('NOT_FOUND', 'Member profile not found.', 404);
    }
    $membership = kcdf_identity_transaction($database, static function () use ($database, $body, $familyId, $profileId, $jwt): array {
        if (!kcdf_identity_lock($database, 'families', $familyId)) {
            throw new RuntimeException('Family not found.', 404);
        }
        if (kcdf_identity_membership($database, $familyId, $profileId) !== null) {
            throw new RuntimeException('This profile is already a member of this family.', 409);
        }
        if ($body['member_role'] === 'primary'
            && kcdf_identity_exists($database, 'family_members', [
                'family_id' => $familyId,
                'member_role' => 'primary',
                'status' => 'active',
            ])) {
            throw new RuntimeException('This family already has a primary member. Only one primary member is allowed.', 409);
        }
        $removed = kcdf_identity_membership($database, $familyId, $profileId, false);
        if ($removed !== null && $removed['status'] === 'removed') {
            $database->update('family_members', [
                'relationship_type' => $body['relationship_type'],
                'member_role' => $body['member_role'],
                'status' => 'active',
            ], ['id' => $removed['id']]);
            $id = (int) $removed['id'];
        } else {
            $database->insert('family_members', [
                'family_id' => $familyId,
                'profile_id' => $profileId,
                'relationship_type' => $body['relationship_type'],
                'member_role' => $body['member_role'],
                'status' => 'active',
            ]);
            $id = (int) $database->id();
        }
        $row = kcdf_identity_one($database, 'family_members', ['id' => $id]);
        $row['profile'] = kcdf_identity_profile($database, $profileId);
        kcdf_identity_log($database, $jwt, 'add_member', 'families', $familyId, null, $row);
        return $row;
    });
    kcdf_identity_success($membership, 'Member added to family successfully.', 201);
});
