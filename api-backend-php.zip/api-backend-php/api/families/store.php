<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);

try {
    kcdf_identity_require(kcdf_identity_is_elevated_admin($jwt));
    $body = kcdf_identity_body();
    kcdf_identity_validation(kcdf_identity_validation_fields($body, 'family'));

    $family = kcdf_identity_transaction($database, static function () use ($database, $body, $jwt): array {
        $addressId = !empty($body['address']) ? kcdf_identity_create_address($database, $body['address']) : null;
        $database->insert('families', [
            'family_code' => 'KCDF-TEMP-' . bin2hex(random_bytes(8)),
            'family_name' => $body['family_name'],
            'address_id' => $addressId,
            'status' => 'active',
        ]);
        $id = (int) $database->id();
        $database->update('families', [
            'family_code' => 'KCDF-' . str_pad((string) $id, 4, '0', STR_PAD_LEFT),
        ], ['id' => $id]);
        $family = kcdf_identity_family($database, $id);
        kcdf_identity_log($database, $jwt, 'create', 'families', $id, null, $family);
        return $family;
    });

    kcdf_identity_success($family, 'Family created successfully.', 201);
} catch (Throwable $exception) {
    kcdf_identity_handle_exception($exception);
}
