<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/identity.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);

try {
    $family = kcdf_identity_family($database, $id);
    if ($family === null) {
        kcdf_identity_error('NOT_FOUND', 'Family not found.', 404);
    }

    kcdf_identity_require(kcdf_identity_family_access($database, $jwt, $id, 'view'));
    kcdf_identity_success($family);
} catch (Throwable $exception) {
    kcdf_identity_handle_exception($exception);
}
