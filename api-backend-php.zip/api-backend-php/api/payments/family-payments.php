<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/payments.php';
$familyId = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $familyId): void {
    if (!kcdf_identity_exists($database, 'families', ['id' => $familyId])) {
        kcdf_identity_error('NOT_FOUND', 'Family not found.', 404);
    }
    if (!kcdf_payment_can_view($database, $jwt, $familyId)) {
        kcdf_identity_error('UNAUTHORIZED', 'You do not have permission to view payments for this family.', 403);
    }
    $result = kcdf_payment_page($database, $_GET, $familyId);
    kcdf_identity_response(['success' => true, 'data' => $result['data'], 'meta' => $result['meta']]);
});
