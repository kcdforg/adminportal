<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/payments.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    if (!kcdf_payment_is_accounts_admin($jwt)) {
        kcdf_identity_error('UNAUTHORIZED', 'You do not have permission to update payments.', 403);
    }
    $current = kcdf_payment_read($database->pdo, $id);
    if ($current === null) {
        kcdf_identity_error('NOT_FOUND', 'Payment not found.', 404);
    }
    try {
        kcdf_payment_assert_editable($current);
    } catch (KcdfPaymentException $exception) {
        kcdf_payment_error($exception);
    }
    $body = kcdf_identity_body();
    kcdf_identity_validation(kcdf_payment_validate_update($body));
    $actorId = kcdf_identity_actor($jwt);
    try {
        kcdf_payment_transaction($database, static function (PDO $pdo) use ($database, $jwt, $id, $body, $actorId): void {
            $payment = kcdf_payment_lock_row($pdo, 'payments', $id, $database->type === 'sqlite');
            if ($payment === null) {
                kcdf_payment_fail('NOT_FOUND', 'Payment not found.', 404);
            }
            kcdf_payment_assert_editable($payment);

            $updates = kcdf_payment_update_values($body, $payment, date('Y-m-d H:i:s'));
            if ($updates !== []) {
                $set = [];
                $params = [':id' => $id];
                foreach ($updates as $field => $value) {
                    $set[] = $field . ' = :' . $field;
                    $params[':' . $field] = $value;
                }
                $statement = $pdo->prepare('UPDATE payments SET ' . implode(', ', $set) . ' WHERE id = :id');
                $statement->execute($params);
            }
            if ($payment['enrollment_id'] !== null) {
                kcdf_payment_recalculate_enrollment($pdo, (int) $payment['enrollment_id'], $database->type === 'sqlite');
            }
            $updated = kcdf_payment_read($pdo, $id);
            kcdf_identity_log($database, ['profile_id' => $actorId], 'payment_updated', 'payments', $id, ['status' => $payment['status']], [
                'amount' => $updated['amount'],
                'payment_type' => $updated['payment_type'],
                'status' => $updated['status'],
                'family_id' => $updated['family_id'],
            ]);
        });
    } catch (KcdfPaymentException $exception) {
        kcdf_payment_error($exception);
    }
    kcdf_identity_success(kcdf_payment_read($database->pdo, $id), 'Payment updated successfully.');
});
