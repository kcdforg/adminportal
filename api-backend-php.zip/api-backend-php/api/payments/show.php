<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/payments.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    $payment = kcdf_payment_read($database->pdo, $id);
    if ($payment === null) {
        kcdf_identity_error('NOT_FOUND', 'Payment not found.', 404);
    }
    if (!kcdf_payment_can_view($database, $jwt, (int) $payment['family_id'])) {
        kcdf_identity_error('UNAUTHORIZED', 'You do not have permission to view this payment.', 403);
    }
    kcdf_identity_success($payment);
});
