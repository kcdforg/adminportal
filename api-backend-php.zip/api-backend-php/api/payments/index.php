<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/payments.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt): void {
    if (!kcdf_payment_is_accounts_admin($jwt)) {
        kcdf_identity_error('UNAUTHORIZED', 'You do not have permission to view all payments.', 403);
    }
    $result = kcdf_payment_page($database, $_GET);
    kcdf_identity_response(['success' => true, 'data' => $result['data'], 'meta' => $result['meta']]);
});
