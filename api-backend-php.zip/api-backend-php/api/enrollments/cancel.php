<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/academics.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    $old = kcdf_acad_enrollment($database, $id);
    if ($old === null) kcdf_identity_error('NOT_FOUND', 'Enrollment not found.', 404);
    kcdf_identity_require(kcdf_acad_enrollment_access($database, $jwt, $old, 'cancel'));
    try {
        kcdf_acad_transaction($database, static function () use ($database, $jwt, $id): void {
            $enrollment = kcdf_acad_lock_enrollment($database, $id);
            if ($enrollment === null) kcdf_acad_fail('NOT_FOUND', 'Enrollment not found.', 404);
            if (!kcdf_acad_enrollment_access($database, $jwt, $enrollment, 'cancel')) {
                kcdf_acad_fail('UNAUTHORIZED', 'You are not authorized to perform this action.', 403);
            }
            if ($enrollment['status'] === 'cancelled') kcdf_acad_fail('ALREADY_CANCELLED', 'Enrollment is already cancelled.');
            $oldValues = kcdf_acad_enrollment($database, $id);
            $database->update('enrollments', ['status' => 'cancelled'], ['id' => $id]);
            $database->update('batch_members', ['status' => 'dropped'], [
                'batch_id' => (int) $enrollment['batch_id'],
                'member_id' => (int) $enrollment['member_id'],
            ]);
            $updated = kcdf_acad_enrollment($database, $id);
            kcdf_identity_log($database, ['profile_id' => null], 'cancel', 'enrollments', $id, $oldValues, $updated);
        });
    } catch (KcdfAcademicsException $exception) {
        kcdf_acad_error($exception);
    }
    kcdf_identity_success(kcdf_acad_enrollment($database, $id), 'Enrollment cancelled successfully.');
});
