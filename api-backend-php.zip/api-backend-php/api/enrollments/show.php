<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/academics.php';
$id = (int) ($_SERVER['ROUTE_PARAMS']['id'] ?? 0);
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt, $id): void {
    $enrollment = kcdf_acad_enrollment($database, $id, true);
    if ($enrollment === null) kcdf_identity_error('NOT_FOUND', 'Enrollment not found.', 404);
    kcdf_identity_require(kcdf_acad_enrollment_access($database, $jwt, $enrollment, 'view'));
    kcdf_identity_success($enrollment);
});
