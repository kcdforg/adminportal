<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/services/academics.php';
[$database, $jwt] = kcdf_identity_context($bootstrap);
kcdf_identity_run($database, static function () use ($database, $jwt): void {
    $body = kcdf_identity_body();
    $errors = [];
    foreach (['family_id', 'member_id', 'batch_id'] as $field) {
        if (empty($body[$field])) $errors[$field] = ["The {$field} field is required."];
        elseif (!is_numeric($body[$field])) $errors[$field] = ["The {$field} must be a valid integer."];
    }
    kcdf_identity_validation($errors);
    $familyId = (int) $body['family_id'];
    $memberId = (int) $body['member_id'];
    $batchId = (int) $body['batch_id'];
    if (!kcdf_identity_is_admin($jwt) && !kcdf_acad_primary_in_family($database, kcdf_identity_id($jwt), $familyId)) {
        kcdf_identity_error('UNAUTHORIZED', 'You are not authorized to perform this action.', 403);
    }
    if (!kcdf_identity_exists($database, 'families', ['id' => $familyId])) kcdf_identity_error('NOT_FOUND', 'Family not found.', 404);
    if (!kcdf_identity_exists($database, 'family_members', ['family_id' => $familyId, 'profile_id' => $memberId, 'status' => 'active'])) {
        kcdf_identity_validation(['member_id' => ['The member does not belong to the specified family.']]);
    }
    $actorId = kcdf_identity_actor($jwt);
    try {
        $enrollmentId = kcdf_acad_transaction($database, static function () use ($database, $familyId, $memberId, $batchId, $actorId): int {
            $batch = kcdf_acad_lock_batch($database, $batchId);
            if ($batch === null) kcdf_acad_fail('NOT_FOUND', 'Batch not found.', 404);
            if (!in_array($batch['status'], ['upcoming', 'active'], true)) {
                kcdf_acad_fail('BATCH_NOT_ENROLLABLE', 'Enrollment is only allowed for upcoming or active batches.');
            }
            if ($database->has('enrollments', ['member_id' => $memberId, 'batch_id' => $batchId])) {
                kcdf_acad_fail('ENROLLMENT_EXISTS', 'This member is already enrolled in this batch.');
            }
            if ($batch['capacity'] !== null && (int) $database->count('batch_members', ['batch_id' => $batchId, 'status' => 'active']) >= (int) $batch['capacity']) {
                kcdf_acad_fail('BATCH_FULL', 'This batch has reached its maximum capacity.');
            }
            $program = kcdf_acad_program($database, (int) $batch['program_id']);
            $fee = $program['fee_amount'] ?? 0;
            $now = date('Y-m-d H:i:s');
            $database->insert('enrollments', [
                'family_id' => $familyId, 'member_id' => $memberId, 'batch_id' => $batchId,
                'enrolled_by_member_id' => $actorId, 'enrolled_at' => $now,
                'status' => 'active', 'payment_status' => 'unpaid', 'fee_amount' => $fee,
            ]);
            $newId = (int) $database->id();
            $database->insert('batch_members', [
                'batch_id' => $batchId, 'member_id' => $memberId, 'joined_at' => $now, 'status' => 'active',
            ]);
            $enrollment = kcdf_acad_enrollment($database, $newId);
            kcdf_identity_log($database, ['profile_id' => $actorId], 'create', 'enrollments', $newId, null, $enrollment);
            return $newId;
        });
    } catch (KcdfAcademicsException $exception) {
        kcdf_acad_error($exception);
    } catch (PDOException $exception) {
        if (in_array((string) $exception->getCode(), ['23000', '19'], true)) {
            kcdf_identity_error('ENROLLMENT_EXISTS', 'This member is already enrolled in this batch.', 422);
        }
        throw $exception;
    }
    kcdf_identity_success(kcdf_acad_enrollment($database, $enrollmentId), 'Enrollment created successfully.', 201);
});
