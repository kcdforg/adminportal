<?php

declare(strict_types=1);

require_once __DIR__ . '/identity.php';

final class KcdfPaymentException extends RuntimeException
{
    public function __construct(
        public readonly string $errorCode,
        string $message,
        public readonly int $status = 422,
        public readonly array $details = []
    ) {
        parent::__construct($message);
    }
}

function kcdf_payment_fail(string $code, string $message, int $status = 422, array $details = []): never
{
    throw new KcdfPaymentException($code, $message, $status, $details);
}

function kcdf_payment_error(KcdfPaymentException $exception): never
{
    kcdf_identity_error($exception->errorCode, $exception->getMessage(), $exception->status, $exception->details);
}

function kcdf_payment_is_accounts_admin(array $jwt): bool
{
    return count(array_intersect(kcdf_identity_roles($jwt), ['admin_super', 'admin_accounts'])) > 0;
}

function kcdf_payment_is_admin(array $jwt): bool
{
    return kcdf_identity_is_admin($jwt);
}

function kcdf_payment_primary_member(Medoo\Medoo $database, array $jwt, int $familyId): bool
{
    $profileId = kcdf_identity_id($jwt);
    return $profileId > 0 && $database->has('family_members', [
        'family_id' => $familyId,
        'profile_id' => $profileId,
        'member_role' => 'primary',
        'status' => 'active',
    ]);
}

function kcdf_payment_can_view(Medoo\Medoo $database, array $jwt, int $familyId): bool
{
    return kcdf_payment_is_admin($jwt) || kcdf_payment_primary_member($database, $jwt, $familyId);
}

function kcdf_payment_assert_family_active(?array $family): void
{
    if ($family === null) {
        kcdf_payment_fail('NOT_FOUND', 'Family not found.', 404);
    }
    if (($family['status'] ?? null) !== 'active') {
        kcdf_payment_fail('NOT_FOUND', 'Family is not active.', 404);
    }
}

function kcdf_payment_assert_enrollment_family(?array $enrollment, int $familyId): void
{
    if ($enrollment === null) {
        kcdf_payment_fail('NOT_FOUND', 'Enrollment not found.', 404);
    }
    if ((int) ($enrollment['family_id'] ?? 0) !== $familyId) {
        kcdf_payment_fail('NOT_FOUND', 'Enrollment does not belong to the specified family.', 404);
    }
}

function kcdf_payment_assert_editable(array $payment): void
{
    if (($payment['status'] ?? null) === 'completed') {
        kcdf_payment_fail('PAYMENT_COMPLETED', 'A completed payment cannot be edited. Create a refund payment instead.');
    }
}

function kcdf_payment_update_values(array $data, array $payment, string $completedAt): array
{
    $updates = [];
    if (isset($data['status'])) {
        $updates['status'] = $data['status'];
        if ($data['status'] === 'completed' && ($payment['paid_at'] ?? null) === null) {
            $updates['paid_at'] = $completedAt;
        }
    }
    foreach (['transaction_reference', 'notes'] as $field) {
        if (array_key_exists($field, $data)) {
            $updates[$field] = $data[$field];
        }
    }
    return $updates;
}

function kcdf_payment_validate_create(array $data): array
{
    $errors = [];
    $types = ['class_fee', 'donation', 'event_fee', 'refund'];
    $methods = ['cash', 'bank_transfer', 'upi', 'card', 'cheque', 'online'];
    $statuses = ['pending', 'completed', 'failed'];
    if (empty($data['family_id'])) {
        $errors['family_id'] = ['The family_id field is required.'];
    } elseif (!is_numeric($data['family_id'])) {
        $errors['family_id'] = ['The family_id must be a valid integer.'];
    }
    if (empty($data['payment_type'])) {
        $errors['payment_type'] = ['The payment_type field is required.'];
    } elseif (!in_array($data['payment_type'], $types, true)) {
        $errors['payment_type'] = ['The payment_type must be one of: ' . implode(', ', $types) . '.'];
    }
    $paymentType = $data['payment_type'] ?? '';
    if ($paymentType === 'class_fee') {
        if (empty($data['enrollment_id'])) {
            $errors['enrollment_id'] = ['The enrollment_id is required for class_fee payments.'];
        } elseif (!is_numeric($data['enrollment_id'])) {
            $errors['enrollment_id'] = ['The enrollment_id must be a valid integer.'];
        }
    } elseif (!empty($data['enrollment_id']) && !is_numeric($data['enrollment_id'])) {
        $errors['enrollment_id'] = ['The enrollment_id must be a valid integer.'];
    }
    if (!isset($data['amount']) || $data['amount'] === '') {
        $errors['amount'] = ['The amount field is required.'];
    } elseif (!is_numeric($data['amount'])) {
        $errors['amount'] = ['The amount must be a numeric value.'];
    } elseif ((float) $data['amount'] < 0.01) {
        $errors['amount'] = ['The amount must be at least 0.01.'];
    } elseif (kcdf_payment_decimal_places($data['amount']) > 2) {
        $errors['amount'] = ['The amount must not exceed 2 decimal places.'];
    }
    if (empty($data['payment_method'])) {
        $errors['payment_method'] = ['The payment_method field is required.'];
    } elseif (!in_array($data['payment_method'], $methods, true)) {
        $errors['payment_method'] = ['The payment_method must be one of: ' . implode(', ', $methods) . '.'];
    }
    $method = $data['payment_method'] ?? '';
    if ($method !== 'cash' && in_array($method, $methods, true) && empty($data['transaction_reference'])) {
        $errors['transaction_reference'] = ['The transaction_reference is required for non-cash payments.'];
    }
    if (empty($data['status'])) {
        $errors['status'] = ['The status field is required.'];
    } elseif (!in_array($data['status'], $statuses, true)) {
        $errors['status'] = ['The status must be one of: ' . implode(', ', $statuses) . '.'];
    }
    if (!empty($data['notes']) && strlen((string) $data['notes']) > 1000) {
        $errors['notes'] = ['The notes must not exceed 1000 characters.'];
    }
    return $errors;
}

function kcdf_payment_validate_update(array $data): array
{
    $errors = [];
    if (isset($data['status']) && !in_array($data['status'], ['pending', 'completed', 'failed'], true)) {
        $errors['status'] = ['The status must be one of: pending, completed, failed.'];
    }
    if (isset($data['notes']) && strlen((string) $data['notes']) > 1000) {
        $errors['notes'] = ['The notes must not exceed 1000 characters.'];
    }
    return $errors;
}

function kcdf_payment_decimal_places($value): int
{
    $string = (string) $value;
    $dot = strpos($string, '.');
    return $dot === false ? 0 : strlen($string) - $dot - 1;
}

function kcdf_payment_transaction(Medoo\Medoo $database, callable $callback)
{
    $pdo = $database->pdo;
    $sqlite = $database->type === 'sqlite';
    if ($sqlite) {
        $pdo->exec('BEGIN IMMEDIATE');
    } else {
        $pdo->beginTransaction();
    }
    try {
        $result = $callback($pdo);
        if ($sqlite) {
            $pdo->exec('COMMIT');
        } else {
            $pdo->commit();
        }
        return $result;
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) {
            if ($sqlite) {
                $pdo->exec('ROLLBACK');
            } else {
                $pdo->rollBack();
            }
        }
        throw $exception;
    }
}

function kcdf_payment_lock_row(PDO $pdo, string $table, int $id, bool $sqlite): ?array
{
    if (!in_array($table, ['payments', 'enrollments'], true)) {
        throw new InvalidArgumentException('Unsupported table requested for payment row locking.');
    }
    $sql = 'SELECT * FROM ' . $table . ' WHERE id = :id' . ($sqlite ? '' : ' FOR UPDATE');
    $statement = $pdo->prepare($sql);
    $statement->execute([':id' => $id]);
    $row = $statement->fetch(PDO::FETCH_ASSOC);
    return is_array($row) ? kcdf_identity_cast_ids($row) : null;
}

function kcdf_payment_recalculate_enrollment(PDO $pdo, int $enrollmentId, bool $sqlite): void
{
    $enrollment = kcdf_payment_lock_row($pdo, 'enrollments', $enrollmentId, $sqlite);
    if ($enrollment === null) {
        return;
    }
    $statement = $pdo->prepare(
        "SELECT COALESCE(SUM(CASE WHEN payment_type = 'refund' THEN -amount ELSE amount END), 0) " .
        "FROM payments WHERE enrollment_id = :enrollment_id AND status = 'completed'"
    );
    $statement->execute([':enrollment_id' => $enrollmentId]);
    $netPaid = (float) $statement->fetchColumn();
    $feeAmount = (float) $enrollment['fee_amount'];
    if ($netPaid <= 0) {
        $paymentStatus = 'unpaid';
    } elseif ($netPaid < $feeAmount) {
        $paymentStatus = 'partial';
    } else {
        $paymentStatus = 'paid';
    }
    $update = $pdo->prepare('UPDATE enrollments SET payment_status = :payment_status WHERE id = :id');
    $update->execute([':payment_status' => $paymentStatus, ':id' => $enrollmentId]);
}

function kcdf_payment_read(PDO $pdo, int $id): ?array
{
    $statement = $pdo->prepare('SELECT * FROM payments WHERE id = :id');
    $statement->execute([':id' => $id]);
    $row = $statement->fetch(PDO::FETCH_ASSOC);
    if (!is_array($row)) {
        return null;
    }
    unset($row['updated_at']);
    return kcdf_payment_format_row(kcdf_identity_cast_ids($row));
}

function kcdf_payment_format_row(array $row): array
{
    if (array_key_exists('amount', $row)) {
        $row['amount'] = number_format((float) $row['amount'], 2, '.', '');
    }
    return $row;
}

function kcdf_payment_page(Medoo\Medoo $database, array $filters, int $familyId = 0): array
{
    $where = [];
    if ($familyId > 0) {
        $where['family_id'] = $familyId;
    } elseif (!empty($filters['family_id'])) {
        $where['family_id'] = (int) $filters['family_id'];
    }
    foreach (['payment_type', 'status', 'payment_method'] as $field) {
        if (!empty($filters[$field])) {
            $where[$field] = $filters[$field];
        }
    }
    if (!empty($filters['paid_at_from'])) {
        $where['paid_at[>=]'] = $filters['paid_at_from'];
    }
    if (!empty($filters['paid_at_to'])) {
        $where['paid_at[<=]'] = $filters['paid_at_to'];
    }
    $total = (int) $database->count('payments', $where);
    $perPage = min(max((int) ($filters['per_page'] ?? 20), 1), 100);
    $page = max((int) ($filters['page'] ?? 1), 1);
    $rows = $database->select('payments', '*', array_merge($where, [
        'ORDER' => ['created_at' => 'DESC'],
        'LIMIT' => [($page - 1) * $perPage, $perPage],
    ])) ?? [];
    $data = [];
    foreach ($rows as $row) {
        unset($row['updated_at']);
        $data[] = kcdf_payment_format_row(kcdf_identity_cast_ids($row));
    }
    return [
        'data' => $data,
        'meta' => [
            'total' => $total,
            'per_page' => $perPage,
            'current_page' => $page,
            'last_page' => max(1, (int) ceil($total / $perPage)),
        ],
    ];
}
