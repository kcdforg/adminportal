<?php

declare(strict_types=1);

function kcdf_identity_response(array $payload, int $status = 200): never
{
    http_response_code($status);
    echo kcdf_json_encode($payload);
    exit;
}

function kcdf_identity_error(string $code, string $message, int $status, array $details = []): never
{
    kcdf_json_error($code, $message, $status, $details);
}

function kcdf_identity_success($data = null, string $message = 'OK', int $status = 200): never
{
    kcdf_json_success($data, $message, $status);
}

function kcdf_identity_auth(): array
{
    try {
        return checkAuth();
    } catch (RuntimeException $exception) {
        kcdf_identity_error('UNAUTHENTICATED', $exception->getMessage(), 401);
    }
}

function kcdf_identity_roles(array $jwt): array
{
    return array_values(array_unique(array_map('strval', (array) ($jwt['roles'] ?? []))));
}

function kcdf_identity_is_admin(array $jwt): bool
{
    return count(array_intersect(kcdf_identity_roles($jwt), [
        'admin_super', 'admin_program_manager', 'admin_accounts', 'admin_readonly',
    ])) > 0;
}

function kcdf_identity_is_elevated_admin(array $jwt): bool
{
    return count(array_intersect(kcdf_identity_roles($jwt), ['admin_super', 'admin_program_manager'])) > 0;
}

function kcdf_identity_require(bool $allowed): void
{
    if (!$allowed) {
        kcdf_identity_error('UNAUTHORIZED', 'You are not authorized to perform this action.', 403);
    }
}

function kcdf_identity_id(array $jwt): int
{
    return (int) ($jwt['profile_id'] ?? 0);
}

function kcdf_identity_body(): array
{
    return kcdf_read_json_body();
}

function kcdf_identity_actor(array $jwt): ?int
{
    $id = kcdf_identity_id($jwt);
    return $id > 0 ? $id : null;
}

function kcdf_identity_log(Medoo\Medoo $database, array $jwt, string $action, string $type, int $id, ?array $old, ?array $new): void
{
    $database->insert('activity_logs', [
        'actor_profile_id' => kcdf_identity_actor($jwt),
        'action' => $action,
        'entity_type' => $type,
        'entity_id' => $id,
        'old_values' => $old === null ? null : json_encode($old, JSON_THROW_ON_ERROR),
        'new_values' => $new === null ? null : json_encode($new, JSON_THROW_ON_ERROR),
    ]);
}

function kcdf_identity_transaction(Medoo\Medoo $database, callable $callback)
{
    $pdo = $database->pdo;
    $pdo->beginTransaction();
    try {
        $result = $callback();
        $pdo->commit();
        return $result;
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $exception;
    }
}

function kcdf_identity_date(string $value): bool
{
    $date = DateTime::createFromFormat('Y-m-d', $value);
    return $date !== false && $date->format('Y-m-d') === $value;
}

function kcdf_identity_validation(array $errors): void
{
    if ($errors !== []) {
        kcdf_identity_error('VALIDATION_FAILED', 'Validation failed', 422, $errors);
    }
}

function kcdf_identity_one(Medoo\Medoo $database, string $table, array $where, array $columns = ['*']): ?array
{
    $row = $database->get($table, $columns, $where);
    return is_array($row) ? kcdf_identity_cast_ids($row) : null;
}

function kcdf_identity_exists(Medoo\Medoo $database, string $table, array $where): bool
{
    return $database->has($table, $where);
}

function kcdf_identity_lock(Medoo\Medoo $database, string $table, int $id): bool
{
    if (!in_array($table, ['families', 'member_profiles'], true)) {
        throw new InvalidArgumentException('Unsupported table requested for identity row locking.');
    }
    if ($database->type === 'sqlite') {
        return kcdf_identity_exists($database, $table, ['id' => $id]);
    }
    $statement = $database->pdo->prepare('SELECT id FROM ' . $table . ' WHERE id = :id FOR UPDATE');
    $statement->execute([':id' => $id]);
    return $statement->fetchColumn() !== false;
}

function kcdf_identity_many(Medoo\Medoo $database, string $table, array $columns = ['*'], array $where = []): array
{
    return array_map('kcdf_identity_cast_ids', $database->select($table, $columns, $where) ?? []);
}

function kcdf_identity_cast_ids(array $row): array
{
    foreach ($row as $key => $value) {
        if ($value !== null && ($key === 'id' || str_ends_with($key, '_id')) && ctype_digit((string) $value)) {
            $row[$key] = (int) $value;
        }
    }
    return $row;
}

function kcdf_identity_profile(Medoo\Medoo $database, int $id): ?array
{
    return kcdf_identity_one($database, 'member_profiles', ['id' => $id]);
}

function kcdf_identity_address(Medoo\Medoo $database, $id): ?array
{
    if (!$id) {
        return null;
    }
    return kcdf_identity_one($database, 'addresses', ['id' => $id]);
}

function kcdf_identity_family(Medoo\Medoo $database, int $id): ?array
{
    $family = kcdf_identity_one($database, 'families', ['id' => $id]);
    if ($family !== null) {
        $family['address'] = kcdf_identity_address($database, $family['address_id']);
    }
    return $family;
}

function kcdf_identity_trainer(Medoo\Medoo $database, int $id): ?array
{
    $trainer = kcdf_identity_one($database, 'trainers', ['id' => $id]);
    if ($trainer !== null) {
        $trainer['profile'] = kcdf_identity_profile($database, (int) $trainer['profile_id']);
        $trainer['address'] = kcdf_identity_address($database, $trainer['address_id']);
        if ($trainer['joined_at'] !== null) {
            $trainer['joined_at'] .= ' 00:00:00';
        }
    }
    return $trainer;
}

function kcdf_identity_admin(Medoo\Medoo $database, int $id): ?array
{
    $admin = kcdf_identity_one($database, 'admins', ['id' => $id]);
    if ($admin !== null) {
        $admin['profile'] = kcdf_identity_profile($database, (int) $admin['profile_id']);
    }
    return $admin;
}

function kcdf_identity_entity(Medoo\Medoo $database, int $id): ?array
{
    $entity = kcdf_identity_one($database, 'entities', ['id' => $id]);
    if ($entity !== null && $entity['meta'] !== null) {
        $entity['meta'] = json_decode((string) $entity['meta'], true);
    }
    return $entity;
}

function kcdf_identity_membership(Medoo\Medoo $database, int $familyId, int $profileId, bool $activeOnly = true): ?array
{
    $where = ['family_id' => $familyId, 'profile_id' => $profileId];
    if ($activeOnly) {
        $where['status'] = 'active';
    }
    return kcdf_identity_one($database, 'family_members', $where);
}

function kcdf_identity_primary_same_family(Medoo\Medoo $database, int $requesterId, int $targetId): bool
{
    $families = $database->select('family_members', 'family_id', [
        'profile_id' => $requesterId,
        'member_role' => 'primary',
        'status' => 'active',
    ]) ?? [];
    if ($families === []) {
        return false;
    }
    return $database->has('family_members', [
        'family_id' => array_values(array_unique($families)),
        'profile_id' => $targetId,
        'status' => 'active',
    ]);
}

function canViewFamily(Medoo\Medoo $database, array $jwt, int $familyId): bool
{
    if (kcdf_identity_is_admin($jwt)) {
        return true;
    }

    $membership = kcdf_identity_membership($database, $familyId, kcdf_identity_id($jwt));
    if ($membership === null) {
        return false;
    }

    return $membership['member_role'] !== 'student';
}

function canEditFamily(Medoo\Medoo $database, array $jwt, int $familyId): bool
{
    if (kcdf_identity_is_elevated_admin($jwt)) {
        return true;
    }

    $membership = kcdf_identity_membership($database, $familyId, kcdf_identity_id($jwt));
    if ($membership === null) {
        return false;
    }

    return $membership['member_role'] === 'primary';
}

function canViewMember(Medoo\Medoo $database, array $jwt, int $profileId): bool
{
    if (kcdf_identity_is_admin($jwt)) {
        return true;
    }

    $requesterId = kcdf_identity_id($jwt);
    if ($requesterId === $profileId) {
        return true;
    }

    return kcdf_identity_primary_same_family($database, $requesterId, $profileId);
}

function canEditMember(Medoo\Medoo $database, array $jwt, int $profileId): bool
{
    if (kcdf_identity_is_admin($jwt)) {
        return true;
    }

    return kcdf_identity_id($jwt) === $profileId;
}

function canManageMemberRelations(Medoo\Medoo $database, array $jwt, int $profileId): bool
{
    return canViewMember($database, $jwt, $profileId)
        && kcdf_identity_primary_same_family($database, kcdf_identity_id($jwt), $profileId);
}

function kcdf_identity_family_access(Medoo\Medoo $database, array $jwt, int $familyId, string $permission): bool
{
    return match ($permission) {
        'view' => canViewFamily($database, $jwt, $familyId),
        'edit' => canEditFamily($database, $jwt, $familyId),
        default => false,
    };
}

function kcdf_identity_member_access(Medoo\Medoo $database, array $jwt, int $profileId, string $permission): bool
{
    return match ($permission) {
        'view' => canViewMember($database, $jwt, $profileId),
        'edit' => canEditMember($database, $jwt, $profileId),
        'manage_relations' => canManageMemberRelations($database, $jwt, $profileId),
        default => kcdf_identity_primary_same_family($database, kcdf_identity_id($jwt), $profileId),
    };
}

function kcdf_validation_text_field(
    array &$errors,
    string $field,
    $value,
    int $maxLength,
    string $requiredMessage,
    string $emptyMessage,
    string $tooLongMessage,
    bool $isRequired = true
): void {
    if ($value === null || $value === [] || $value === false) {
        if ($isRequired) {
            $errors[$field] = [$requiredMessage];
        }
        return;
    }

    $stringValue = trim((string) $value);
    if ($stringValue === '') {
        $errors[$field] = [$emptyMessage];
        return;
    }

    if (strlen((string) $value) > $maxLength) {
        $errors[$field] = [$tooLongMessage];
    }
}

function kcdf_validation_choice(array &$errors, string $field, $value, array $allowed, string $errorMessage): void
{
    if ($value === null || $value === '' || $value === []) {
        return;
    }

    if (!in_array($value, $allowed, true)) {
        $errors[$field] = [$errorMessage];
    }
}

function kcdf_validation_required(array &$errors, string $field, $value, string $message): void
{
    if (empty($value)) {
        $errors[$field] = [$message];
    }
}

function kcdf_validation_positive_int(array &$errors, string $field, $value, string $message): void
{
    if ($value === null || $value === '' || $value === [] || $value === false) {
        return;
    }

    if (!is_numeric($value) || (int) $value <= 0) {
        $errors[$field] = [$message];
    }
}

function kcdf_validation_non_negative_number(array &$errors, string $field, $value, string $message, ?string $decimalMessage = null): void
{
    if ($value === null || $value === '' || $value === [] || $value === false) {
        return;
    }

    if (!is_numeric($value) || (float) $value < 0) {
        $errors[$field] = [$message];
        return;
    }

    if ($decimalMessage !== null && is_numeric($value)) {
        $numeric = (string) $value;
        $decimalIndex = strpos($numeric, '.');
        if ($decimalIndex !== false) {
            $decimalPlaces = strlen(substr($numeric, $decimalIndex + 1));
            if ($decimalPlaces > 2) {
                $errors[$field] = [$decimalMessage];
            }
        }
    }
}

function kcdf_validation_length(array &$errors, string $field, $value, int $maxLength, string $requiredMessage, string $tooLongMessage): void
{
    kcdf_validation_text_field(
        $errors,
        $field,
        $value,
        $maxLength,
        $requiredMessage,
        $requiredMessage,
        $tooLongMessage,
        true
    );
}

function kcdf_validation_email(array &$errors, string $field, $value, string $message = 'The email must be a valid email address.'): void
{
    if ($value === null || $value === '' || $value === []) {
        return;
    }

    if (!filter_var((string) $value, FILTER_VALIDATE_EMAIL)) {
        $errors[$field] = [$message];
    }
}

function kcdf_validation_mobile(array &$errors, string $field, $value, string $invalidMessage = 'The mobile must contain digits only.', string $shortMessage = 'The mobile must be at least 10 digits.'): void
{
    if ($value === null || $value === '' || $value === []) {
        return;
    }

    $digits = (string) $value;
    if (!ctype_digit($digits)) {
        $errors[$field] = [$invalidMessage];
        return;
    }

    if (strlen($digits) < 10) {
        $errors[$field] = [$shortMessage];
    }
}

function kcdf_validation_date(array &$errors, string $field, $value, string $message = 'The date must be a valid date (YYYY-MM-DD).'): void
{
    if ($value === null || $value === '' || $value === []) {
        return;
    }

    if (!kcdf_identity_date((string) $value)) {
        $errors[$field] = [$message];
    }
}

function kcdf_validation_time(array &$errors, string $field, $value, string $message = 'The time must be a valid time (HH:MM).'): void
{
    if ($value === null || $value === '' || $value === []) {
        return;
    }

    if (!preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', (string) $value)) {
        $errors[$field] = [$message];
    }
}

function kcdf_identity_address_errors($address): array
{
    if ($address === null || $address === []) {
        return [];
    }
    if (!is_array($address)) {
        return ['address' => ['The address must be an object.']];
    }
    $errors = [];
    foreach (['address_line_1', 'city', 'country'] as $field) {
        if (empty($address[$field])) {
            $errors['address.' . $field] = ['The address.' . $field . ' field is required when address is provided.'];
        }
    }
    return $errors;
}

function kcdf_identity_create_address(Medoo\Medoo $database, array $data): int
{
    $database->insert('addresses', [
        'address_label' => $data['address_label'] ?? 'home',
        'address_line_1' => $data['address_line_1'],
        'address_line_2' => $data['address_line_2'] ?? null,
        'city' => $data['city'],
        'state' => $data['state'] ?? null,
        'postal_code' => $data['postal_code'] ?? null,
        'country' => $data['country'] ?? 'India',
    ]);
    return (int) $database->id();
}

function kcdf_identity_update_address(Medoo\Medoo $database, int $id, array $data): void
{
    $allowed = ['address_label', 'address_line_1', 'address_line_2', 'city', 'state', 'postal_code', 'country'];
    $update = [];
    foreach ($allowed as $field) {
        if (array_key_exists($field, $data)) {
            $update[$field] = $data[$field];
        }
    }
    if ($update !== []) {
        $database->update('addresses', $update, ['id' => $id]);
    }
}

function kcdf_identity_validation_fields(array $data, string $kind, bool $update = false): array
{
    $errors = [];
    $requiredText = static fn (string $field, string $requiredMessage, int $maxLength, string $tooLongMessage): void =>
        kcdf_validation_text_field($errors, $field, $data[$field] ?? null, $maxLength, $requiredMessage, $requiredMessage, $tooLongMessage, !$update);

    if ($kind === 'member') {
        foreach (['first_name', 'last_name'] as $field) {
            $requiredText($field, "The {$field} field is required.", 100, "The {$field} may not be greater than 100 characters.");
            if (array_key_exists($field, $data) && $data[$field] !== null && $data[$field] !== '' && $data[$field] !== []) {
                $trimmed = trim((string) $data[$field]);
                if ($trimmed === '') {
                    $errors[$field] = ["The {$field} field cannot be empty."];
                }
            }
        }
        kcdf_validation_email($errors, 'email', $data['email'] ?? null);
        kcdf_validation_mobile($errors, 'mobile', $data['mobile'] ?? null);
        kcdf_validation_choice($errors, 'gender', $data['gender'] ?? null, ['male', 'female', 'other'], 'The gender must be one of: male, female, other.');
        kcdf_validation_choice($errors, 'status', $data['status'] ?? null, ['active', 'inactive', 'suspended'], 'The status must be one of: active, inactive, suspended.');
        if (!empty($data['date_of_birth'])) {
            if (!kcdf_identity_date((string) $data['date_of_birth'])) {
                $errors['date_of_birth'] = ['The date_of_birth must be a valid date (YYYY-MM-DD).'];
            } elseif (new DateTime((string) $data['date_of_birth']) > new DateTime('today')) {
                $errors['date_of_birth'] = ['The date_of_birth must not be in the future.'];
            }
        }
    } elseif ($kind === 'family') {
        $requiredText('family_name', 'The family_name field is required.', 255, 'The family_name may not be greater than 255 characters.');
        if (array_key_exists('family_name', $data) && $data['family_name'] !== null && $data['family_name'] !== [] && $data['family_name'] !== false && trim((string) $data['family_name']) === '') {
            $errors['family_name'] = ['The family_name field cannot be empty.'];
        }
        kcdf_validation_choice($errors, 'status', $data['status'] ?? null, ['active', 'inactive'], 'The status must be one of: active, inactive.');
        if (!empty($data['address'])) {
            $errors = array_merge($errors, kcdf_identity_address_errors($data['address']));
        }
    } elseif ($kind === 'trainer') {
        if (!$update && empty($data['profile_id'])) {
            $errors['profile_id'] = ['The profile_id field is required.'];
        } elseif (!$update && !is_numeric($data['profile_id'])) {
            $errors['profile_id'] = ['The profile_id must be a valid integer.'];
        }
        if (isset($data['specialization'])) {
            kcdf_validation_length($errors, 'specialization', $data['specialization'], 255, 'The specialization field is required.', 'The specialization may not be greater than 255 characters.');
        }
        if (array_key_exists('experience_years', $data) && $data['experience_years'] !== null
            && (!is_numeric($data['experience_years']) || (int) $data['experience_years'] < 0 || (int) $data['experience_years'] > 60)) {
            $errors['experience_years'] = ['The experience_years must be an integer between 0 and 60.'];
        }
        if (!empty($data['joined_at'])) {
            kcdf_validation_date($errors, 'joined_at', $data['joined_at'], 'The joined_at must be a valid date (YYYY-MM-DD).');
        }
        if ($update) {
            kcdf_validation_choice($errors, 'status', $data['status'] ?? null, ['active', 'inactive', 'on_leave'], 'The status must be one of: active, inactive, on_leave.');
        }
        if (!empty($data['address'])) {
            $errors = array_merge($errors, kcdf_identity_address_errors($data['address']));
        }
    } elseif ($kind === 'entity') {
        $types = ['school', 'college', 'organization', 'hospital', 'association'];
        if (!$update && empty($data['entity_type'])) {
            $errors['entity_type'] = ['The entity_type field is required.'];
        }
        kcdf_validation_choice($errors, 'entity_type', $data['entity_type'] ?? null, $types, 'The entity_type must be one of: school, college, organization, hospital, association.');
        if (!$update && empty($data['name'])) {
            $errors['name'] = ['The name field is required.'];
        } elseif (array_key_exists('name', $data) && empty($data['name'])) {
            $errors['name'] = ['The name field cannot be empty.'];
        } elseif (isset($data['name'])) {
            kcdf_validation_length($errors, 'name', $data['name'], 255, 'The name field is required.', 'The name may not be greater than 255 characters.');
        }
        if ($update) {
            kcdf_validation_choice($errors, 'status', $data['status'] ?? null, ['active', 'inactive'], 'The status must be one of: active, inactive.');
        }
    }
    return $errors;
}

function kcdf_identity_context(array $bootstrap): array
{
    $database = $bootstrap['database'] ?? null;
    if (!$database instanceof Medoo\Medoo) {
        kcdf_identity_error('STARTUP_ERROR', 'The API runtime has not been initialized.', 500);
    }

    return [$database, kcdf_identity_auth()];
}

function kcdf_identity_handle_exception(Throwable $exception): never
{
    if ($exception instanceof PDOException) {
        error_log('Identity endpoint database failure: ' . $exception->getMessage());
        if ((string) $exception->getCode() === '23000') {
            kcdf_identity_error('DUPLICATE_ENTRY', 'The requested record conflicts with an existing record.', 409);
        }
        kcdf_identity_error('INTERNAL_ERROR', 'The request could not be completed.', 500);
    }

    if ($exception instanceof RuntimeException) {
        if ((int) $exception->getCode() === 404) {
            kcdf_identity_error('NOT_FOUND', $exception->getMessage(), 404);
        }
        if ((int) $exception->getCode() === 409) {
            kcdf_identity_error('DUPLICATE_ENTRY', $exception->getMessage(), 409);
        }
        error_log('Identity endpoint failure: ' . $exception->getMessage());
        kcdf_identity_error('INTERNAL_ERROR', 'The request could not be completed.', 500);
    }

    error_log('Identity endpoint failure: ' . $exception->getMessage());
    kcdf_identity_error('INTERNAL_ERROR', 'The request could not be completed.', 500);
}

function kcdf_identity_run(Medoo\Medoo $database, callable $action): never
{
    try {
        $action();
        kcdf_identity_error('INTERNAL_ERROR', 'The request handler returned without a response.', 500);
    } catch (Throwable $exception) {
        kcdf_identity_handle_exception($exception);
    }
}

function kcdf_identity_paginate(Medoo\Medoo $database, string $table, array $filters, array $filterColumns, array $sortColumns, array $searchColumns = []): array
{
    $where = [];
    foreach ($filterColumns as $name => $column) {
        if (isset($filters[$name]) && $filters[$name] !== '') {
            $where[$column] = $filters[$name];
        }
    }
    if (isset($filters['search']) && $filters['search'] !== '' && $searchColumns !== []) {
        $search = [];
        foreach ($searchColumns as $column) {
            $search[$column . '[~]'] = $filters['search'];
        }
        $where['OR'] = $search;
    }
    $total = (int) $database->count($table, $where);
    $perPage = min(max((int) ($filters['per_page'] ?? 20), 1), 100);
    $page = max((int) ($filters['page'] ?? 1), 1);
    $sort = in_array($filters['sort'] ?? '', $sortColumns, true) ? $filters['sort'] : 'created_at';
    $order = strtolower((string) ($filters['order'] ?? 'desc')) === 'asc' ? 'ASC' : 'DESC';
    $offset = ($page - 1) * $perPage;
    $rows = $database->select($table, '*', array_merge($where, [
        'ORDER' => [$sort => $order],
        'LIMIT' => [$offset, $perPage],
    ])) ?? [];

    return [
        'data' => array_map('kcdf_identity_cast_ids', $rows),
        'meta' => [
            'total' => $total,
            'per_page' => $perPage,
            'current_page' => $page,
            'last_page' => max(1, (int) ceil($total / $perPage)),
        ],
    ];
}
