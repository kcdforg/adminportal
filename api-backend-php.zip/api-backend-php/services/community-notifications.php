<?php

declare(strict_types=1);

require_once __DIR__ . '/identity.php';

final class KcdfCommunityException extends RuntimeException
{
    public function __construct(
        public readonly string $errorCode,
        string $message,
        public readonly int $status = 422,
        public readonly array $details = []
    ) {
        parent::__construct($message);
    }
}

function kcdf_community_fail(string $code, string $message, int $status = 422, array $details = []): never
{
    throw new KcdfCommunityException($code, $message, $status, $details);
}

function kcdf_community_error(KcdfCommunityException $exception): never
{
    kcdf_identity_error($exception->errorCode, $exception->getMessage(), $exception->status, $exception->details);
}

function kcdf_community_transaction(Medoo\Medoo $database, callable $callback)
{
    $pdo = $database->pdo;
    $sqlite = $database->type === 'sqlite';
    if ($sqlite) {
        $pdo->exec('BEGIN IMMEDIATE');
    } else {
        $pdo->beginTransaction();
    }
    try {
        $result = $callback($pdo);
        if ($sqlite) {
            $pdo->exec('COMMIT');
        } else {
            $pdo->commit();
        }
        return $result;
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) {
            if ($sqlite) {
                $pdo->exec('ROLLBACK');
            } else {
                $pdo->rollBack();
            }
        }
        throw $exception;
    }
}

function kcdf_community_is_admin(array $jwt): bool
{
    return kcdf_identity_is_admin($jwt);
}

function kcdf_community_is_parent(array $jwt): bool
{
    return count(array_intersect(kcdf_identity_roles($jwt), ['family_primary', 'family_normal'])) > 0;
}

function kcdf_community_require_admin(array $jwt, string $message = 'Only admins can perform this action.'): void
{
    if (!kcdf_community_is_admin($jwt)) {
        kcdf_identity_error('UNAUTHORIZED', $message, 403);
    }
}

function kcdf_community_member(Medoo\Medoo $database, int $groupId, int $memberId): ?array
{
    return kcdf_identity_one($database, 'group_members', ['group_id' => $groupId, 'member_id' => $memberId]);
}

function kcdf_community_active_member(Medoo\Medoo $database, int $groupId, int $memberId): bool
{
    return $database->has('group_members', ['group_id' => $groupId, 'member_id' => $memberId, 'status' => 'active']);
}

function canViewGroup(Medoo\Medoo $database, array $jwt, array $group): bool
{
    if (kcdf_community_is_admin($jwt)) {
        return true;
    }

    if ($group['visibility'] === 'public') {
        return kcdf_community_is_parent($jwt);
    }

    return kcdf_identity_id($jwt) > 0
        && kcdf_community_active_member($database, (int) $group['id'], kcdf_identity_id($jwt));
}

function canManageGroupMembers(Medoo\Medoo $database, array $jwt, array $group): bool
{
    if (kcdf_community_is_admin($jwt)) {
        return true;
    }

    return kcdf_identity_id($jwt) > 0
        && kcdf_community_active_member($database, (int) $group['id'], kcdf_identity_id($jwt));
}

function kcdf_community_group_access(Medoo\Medoo $database, array $jwt, array $group, string $scope): bool
{
    return match ($scope) {
        'view' => canViewGroup($database, $jwt, $group),
        'members' => canManageGroupMembers($database, $jwt, $group),
        default => canViewGroup($database, $jwt, $group),
    };
}

function kcdf_community_notification_for_member(Medoo\Medoo $database, int $notificationId, int $memberId): ?array
{
    return kcdf_identity_one($database, 'notifications', ['id' => $notificationId, 'member_id' => $memberId]);
}

function kcdf_community_invitation_duplicate(Medoo\Medoo $database, int $senderId, ?string $mobile, ?string $email): bool
{
    $or = [];
    if ($mobile !== null) $or['invite_mobile'] = $mobile;
    if ($email !== null) $or['invite_email'] = $email;
    if ($or === []) return false;
    return $database->has('invitations', [
        'invited_by_member_id' => $senderId,
        'status' => 'pending',
        'OR' => $or,
    ]);
}

function kcdf_community_assert_invitation_pending(array $invitation): void
{
    if (($invitation['status'] ?? null) !== 'pending') {
        kcdf_community_fail('INVITATION_NOT_PENDING', 'This invitation cannot be accepted.');
    }
}

function kcdf_community_group_validation(array $data, string $mode): array
{
    $errors = [];
    $visibility = ['public', 'private', 'invite_only'];
    $statuses = ['active', 'inactive', 'archived'];
    if ($mode === 'create') {
        kcdf_validation_required($errors, 'group_name', $data['group_name'] ?? null, 'The group_name field is required.');
        kcdf_validation_required($errors, 'visibility', $data['visibility'] ?? null, 'The visibility field is required.');
    }
    if (isset($data['group_name']) && strlen((string) $data['group_name']) > 255) {
        $errors['group_name'] = ['The group_name must not exceed 255 characters.'];
    }
    kcdf_validation_choice($errors, 'visibility', $data['visibility'] ?? null, $visibility, 'The visibility must be one of: public, private, invite_only.');
    kcdf_validation_choice($errors, 'status', $data['status'] ?? null, $statuses, 'The status must be one of: active, inactive, archived.');
    if ($mode === 'member-action') {
        kcdf_validation_required($errors, 'action', $data['action'] ?? null, 'The action field is required.');
        kcdf_validation_choice($errors, 'action', $data['action'] ?? null, ['ban', 'remove'], 'The action must be one of: ban, remove.');
    }
    return $errors;
}

function kcdf_community_invitation_validation(array $data, string $mode): array
{
    $errors = [];
    if ($mode === 'create') {
        $hasMobile = !empty($data['invite_mobile']);
        $hasEmail = !empty($data['invite_email']);
        if (!$hasMobile && !$hasEmail) {
            $errors['invite_mobile'] = ['At least one of invite_mobile or invite_email is required.'];
        }
        if ($hasMobile && !preg_match('/^\d{10,}$/', (string) $data['invite_mobile'])) {
            $errors['invite_mobile'] = ['The invite_mobile must contain digits only, minimum 10 digits.'];
        }
        if ($hasEmail && !filter_var($data['invite_email'], FILTER_VALIDATE_EMAIL)) {
            $errors['invite_email'] = ['The invite_email must be a valid email address.'];
        }
        return $errors;
    }
    foreach (['first_name', 'last_name'] as $field) {
        if (empty($data[$field])) {
            $errors[$field] = ["The {$field} field is required."];
        } elseif (strlen((string) $data[$field]) > 100) {
            $errors[$field] = ["The {$field} must not exceed 100 characters."];
        }
    }
    kcdf_validation_required($errors, 'mobile', $data['mobile'] ?? null, 'The mobile field is required.');
    if (isset($data['mobile']) && $data['mobile'] !== '' && !preg_match('/^\d{10,}$/', (string) $data['mobile'])) {
        $errors['mobile'] = ['The mobile must contain digits only, minimum 10 digits.'];
    }
    kcdf_validation_required($errors, 'email', $data['email'] ?? null, 'The email field is required.');
    kcdf_validation_email($errors, 'email', $data['email'] ?? null, 'The email must be a valid email address.');
    kcdf_validation_required($errors, 'password', $data['password'] ?? null, 'The password field is required.');
    if (isset($data['password']) && $data['password'] !== '' && strlen((string) $data['password']) < 8) {
        $errors['password'] = ['The password must be at least 8 characters.'];
    }
    return $errors;
}

function kcdf_community_generate_invite_code(Medoo\Medoo $database): string
{
    do {
        $code = strtoupper(bin2hex(random_bytes(16)));
    } while ($database->has('invitations', ['invite_code' => $code]));
    return $code;
}

function kcdf_community_invitation_expired(string $sentAt, ?int $now = null): bool
{
    $sentTimestamp = strtotime($sentAt);
    return $sentTimestamp === false || ($now ?? time()) > $sentTimestamp + (7 * 24 * 3600);
}

function kcdf_community_notification_common_validation(array $data): array
{
    $errors = [];
    $types = ['in_app', 'push', 'email'];
    if (empty($data['title'])) {
        $errors['title'] = ['The title field is required.'];
    } elseif (strlen((string) $data['title']) > 255) {
        $errors['title'] = ['The title must not exceed 255 characters.'];
    }
    if (empty($data['message'])) {
        $errors['message'] = ['The message field is required.'];
    } elseif (strlen((string) $data['message']) > 2000) {
        $errors['message'] = ['The message must not exceed 2000 characters.'];
    }
    if (empty($data['type'])) {
        $errors['type'] = ['The type field is required.'];
    } elseif (!in_array($data['type'], $types, true)) {
        $errors['type'] = ['The type must be one of: in_app, push, email.'];
    }
    return $errors;
}

function kcdf_community_notification_validation(array $data, string $mode): array
{
    $errors = kcdf_community_notification_common_validation($data);
    if ($mode === 'send') {
        if (!isset($data['member_ids']) || !is_array($data['member_ids']) || $data['member_ids'] === []) {
            $errors['member_ids'] = ['The member_ids field is required and must be a non-empty array.'];
        } else {
            foreach ($data['member_ids'] as $id) {
                if (!is_numeric($id) || (int) $id <= 0) {
                    $errors['member_ids'] = ['All member_ids must be valid positive integers.'];
                    break;
                }
            }
        }
    } else {
        $types = ['batch', 'group', 'all_families'];
        if (empty($data['target_type'])) {
            $errors['target_type'] = ['The target_type field is required.'];
        } elseif (!in_array($data['target_type'], $types, true)) {
            $errors['target_type'] = ['The target_type must be one of: batch, group, all_families.'];
        }
        if (in_array($data['target_type'] ?? '', ['batch', 'group'], true) && empty($data['target_id'])) {
            $errors['target_id'] = ['The target_id is required when target_type is batch or group.'];
        } elseif (isset($data['target_id']) && $data['target_id'] !== '' && (!is_numeric($data['target_id']) || (int) $data['target_id'] < 1)) {
            $errors['target_id'] = ['The target_id must be a valid positive integer.'];
        }
    }
    return $errors;
}

function kcdf_community_paginate(Medoo\Medoo $database, string $table, array $filters, array $where = [], array $filterMap = [], string $sortField = 'created_at', string $order = 'DESC', int $maxPerPage = 100): array
{
    foreach ($filterMap as $input => $column) {
        if (isset($filters[$input]) && $filters[$input] !== '') {
            $where[$column] = $filters[$input];
        }
    }
    $total = (int) $database->count($table, $where);
    $perPage = min(max((int) ($filters['per_page'] ?? 20), 1), $maxPerPage);
    $page = max((int) ($filters['page'] ?? 1), 1);
    $rows = $database->select($table, '*', array_merge($where, [
        'ORDER' => [$sortField => $order],
        'LIMIT' => [($page - 1) * $perPage, $perPage],
    ])) ?? [];
    return [
        'data' => array_map('kcdf_identity_cast_ids', $rows),
        'meta' => ['total' => $total, 'per_page' => $perPage, 'current_page' => $page, 'last_page' => max(1, (int) ceil($total / $perPage))],
    ];
}

function kcdf_community_lock_invitation(Medoo\Medoo $database, string $code): ?array
{
    if ($database->type === 'sqlite') {
        return kcdf_identity_one($database, 'invitations', ['invite_code' => $code]);
    }
    $statement = $database->pdo->prepare('SELECT * FROM invitations WHERE invite_code = :code FOR UPDATE');
    $statement->execute([':code' => $code]);
    $row = $statement->fetch(PDO::FETCH_ASSOC);
    return is_array($row) ? kcdf_identity_cast_ids($row) : null;
}

function kcdf_community_issue_invitation_tokens(Medoo\Medoo $database, array $bootstrap, int $profileId, string $email): array
{
    $repository = new \Kcdf\Repositories\ProfileRepository($database);
    $roleData = $repository->rolesForProfile($profileId);
    $now = time();
    $accessToken = createToken([
        'profile_id' => $profileId,
        'username' => $email,
        'roles' => $roleData['roles'],
        'family_ids' => $roleData['family_ids'],
        'iat' => $now,
        'exp' => $now + (int) ($bootstrap['config']['jwt']['access_ttl'] ?? 900),
    ], 'access');
    $refreshExpiry = $now + (int) ($bootstrap['config']['jwt']['refresh_ttl'] ?? 2592000);
    $refreshToken = createToken(['profile_id' => $profileId, 'iat' => $now, 'exp' => $refreshExpiry], 'refresh');
    $database->insert('refresh_tokens', [
        'profile_id' => $profileId,
        'token_hash' => hash('sha256', $refreshToken),
        'expires_at' => date('Y-m-d H:i:s', $refreshExpiry),
        'created_at' => date('Y-m-d H:i:s'),
    ]);
    return ['access_token' => $accessToken, 'refresh_token' => $refreshToken];
}
