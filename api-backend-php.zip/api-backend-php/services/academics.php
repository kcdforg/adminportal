<?php

declare(strict_types=1);

require_once __DIR__ . '/identity.php';

final class KcdfAcademicsException extends RuntimeException
{
    public function __construct(public readonly string $errorCode, string $message, public readonly int $status = 422, public readonly array $details = [])
    {
        parent::__construct($message);
    }
}

function kcdf_acad_fail(string $code, string $message, int $status = 422, array $details = []): never
{
    throw new KcdfAcademicsException($code, $message, $status, $details);
}

function kcdf_acad_error(KcdfAcademicsException $exception): never
{
    kcdf_identity_error($exception->errorCode, $exception->getMessage(), $exception->status, $exception->details);
}

function kcdf_acad_is_trainer(array $jwt): bool
{
    return in_array('trainer', kcdf_identity_roles($jwt), true);
}

function kcdf_acad_elevated(array $jwt): bool
{
    return kcdf_identity_is_elevated_admin($jwt);
}

function kcdf_acad_trainer_id(Medoo\Medoo $database, array $jwt): ?int
{
    $profileId = kcdf_identity_id($jwt);
    if ($profileId < 1) {
        return null;
    }
    $id = $database->get('trainers', 'id', ['profile_id' => $profileId]);
    return $id === null ? null : (int) $id;
}

function kcdf_acad_member_in_batch(Medoo\Medoo $database, int $memberId, int $batchId): bool
{
    return $database->has('enrollments', [
        'member_id' => $memberId,
        'batch_id' => $batchId,
        'status' => ['active', 'pending'],
    ]);
}

function canViewBatch(Medoo\Medoo $database, array $jwt, array $batch): bool
{
    if (kcdf_identity_is_admin($jwt)) {
        return true;
    }

    $trainerId = kcdf_acad_trainer_id($database, $jwt);
    if (kcdf_acad_is_trainer($jwt) && $trainerId !== null && $trainerId === (int) ($batch['trainer_id'] ?? 0)) {
        return true;
    }

    return kcdf_acad_member_in_batch($database, kcdf_identity_id($jwt), (int) $batch['id']);
}

function canManageBatchMembers(Medoo\Medoo $database, array $jwt, array $batch): bool
{
    if (!kcdf_acad_is_trainer($jwt)) {
        return false;
    }

    return kcdf_acad_trainer_id($database, $jwt) === (int) ($batch['trainer_id'] ?? 0);
}

function canViewSession(Medoo\Medoo $database, array $jwt, array $session, ?array $batch = null): bool
{
    if (kcdf_identity_is_admin($jwt)) {
        return true;
    }

    if (kcdf_acad_is_trainer($jwt) && kcdf_acad_session_trainer($database, $jwt, $session, $batch)) {
        return true;
    }

    return kcdf_acad_member_in_batch($database, kcdf_identity_id($jwt), (int) $session['batch_id']);
}

function canEditSession(Medoo\Medoo $database, array $jwt, array $session, ?array $batch = null): bool
{
    if (kcdf_acad_elevated($jwt)) {
        return true;
    }

    return kcdf_acad_is_trainer($jwt)
        && kcdf_acad_session_trainer($database, $jwt, $session, $batch);
}

function canManageAttendance(Medoo\Medoo $database, array $jwt, array $session, ?array $batch = null): bool
{
    return kcdf_acad_elevated($jwt)
        || (kcdf_acad_is_trainer($jwt) && kcdf_acad_session_trainer($database, $jwt, $session, $batch));
}

function kcdf_acad_batch_access(Medoo\Medoo $database, array $jwt, array $batch, string $scope = 'view'): bool
{
    return match ($scope) {
        'members' => canManageBatchMembers($database, $jwt, $batch),
        default => canViewBatch($database, $jwt, $batch),
    };
}

function kcdf_acad_session_trainer(Medoo\Medoo $database, array $jwt, array $session, ?array $batch = null): bool
{
    $trainerId = kcdf_acad_trainer_id($database, $jwt);
    $effective = $session['trainer_id'] ?? ($batch['trainer_id'] ?? null);
    return $trainerId !== null && $effective !== null && $trainerId === (int) $effective;
}

function kcdf_acad_session_access(Medoo\Medoo $database, array $jwt, array $session, ?array $batch = null, string $scope = 'view'): bool
{
    return match ($scope) {
        'view' => canViewSession($database, $jwt, $session, $batch),
        'edit' => canEditSession($database, $jwt, $session, $batch),
        default => canViewSession($database, $jwt, $session, $batch),
    };
}

function kcdf_acad_attendance_access(Medoo\Medoo $database, array $jwt, array $session, ?array $batch = null): bool
{
    return canManageAttendance($database, $jwt, $session, $batch);
}

function kcdf_acad_page(Medoo\Medoo $database, string $table, array $filters, array $filterColumns, array $sortColumns, string $defaultSort, array $extraWhere = []): array
{
    $where = [];
    foreach ($filterColumns as $input => $column) {
        if (isset($filters[$input]) && $filters[$input] !== '') {
            $where[$column] = $filters[$input];
        }
    }
    $where = array_merge($where, $extraWhere);
    $total = (int) $database->count($table, $where);
    $perPage = min(max((int) ($filters['per_page'] ?? 20), 1), 100);
    $page = max((int) ($filters['page'] ?? 1), 1);
    $sort = in_array($filters['sort'] ?? '', $sortColumns, true) ? $filters['sort'] : $defaultSort;
    $order = strtolower((string) ($filters['order'] ?? 'desc')) === 'asc' ? 'ASC' : 'DESC';
    $rows = $database->select($table, '*', array_merge($where, [
        'ORDER' => [$sort => $order],
        'LIMIT' => [($page - 1) * $perPage, $perPage],
    ])) ?? [];
    return [
        'data' => array_map('kcdf_identity_cast_ids', $rows),
        'meta' => ['total' => $total, 'per_page' => $perPage, 'current_page' => $page, 'last_page' => max(1, (int) ceil($total / $perPage))],
    ];
}

function kcdf_acad_empty_page(array $filters): array
{
    $perPage = min(max((int) ($filters['per_page'] ?? 20), 1), 100);
    return ['data' => [], 'meta' => ['total' => 0, 'per_page' => $perPage, 'current_page' => 1, 'last_page' => 1]];
}

function kcdf_acad_program(Medoo\Medoo $database, int $id): ?array
{
    return kcdf_identity_one($database, 'programs', ['id' => $id]);
}

function kcdf_acad_batch(Medoo\Medoo $database, int $id, bool $relations = true): ?array
{
    $row = kcdf_identity_one($database, 'student_batches', ['id' => $id]);
    if ($row !== null && $relations) {
        $row['program'] = kcdf_acad_program($database, (int) $row['program_id']);
        $row['trainer'] = kcdf_acad_trainer($database, (int) ($row['trainer_id'] ?? 0));
    }
    return $row;
}

function kcdf_acad_trainer(Medoo\Medoo $database, int $id): ?array
{
    if ($id < 1) {
        return null;
    }
    return kcdf_identity_trainer($database, $id);
}

function kcdf_acad_session(Medoo\Medoo $database, int $id, bool $relations = true): ?array
{
    $row = kcdf_identity_one($database, 'batch_sessions', ['id' => $id]);
    if ($row !== null && $relations) {
        $row['batch'] = kcdf_acad_batch($database, (int) $row['batch_id']);
        $row['trainer'] = kcdf_acad_trainer($database, (int) ($row['trainer_id'] ?? 0));
        $row['attendance_locked'] = (bool) $row['attendance_locked'];
    }
    return $row;
}

function kcdf_acad_validate_program(array $data, string $mode): array
{
    $errors = [];
    $types = ['class', 'workshop', 'camp', 'event'];
    $statuses = ['active', 'inactive', 'archived'];
    if ($mode === 'create') {
        kcdf_validation_required($errors, 'program_name', $data['program_name'] ?? null, 'The program_name field is required.');
        kcdf_validation_required($errors, 'program_type', $data['program_type'] ?? null, 'The program_type field is required.');
        if (!array_key_exists('fee_amount', $data)) {
            $errors['fee_amount'] = ['The fee_amount field is required.'];
        }
    }
    if (array_key_exists('program_name', $data)) {
        kcdf_validation_text_field($errors, 'program_name', $data['program_name'], 255, 'The program_name field is required.', 'The program_name field cannot be empty.', 'The program_name may not be greater than 255 characters.', $mode === 'create');
    }
    kcdf_validation_choice($errors, 'program_type', $data['program_type'] ?? null, $types, 'The program_type must be one of: class, workshop, camp, event.');
    if (array_key_exists('fee_amount', $data)) {
        kcdf_validation_non_negative_number($errors, 'fee_amount', $data['fee_amount'], 'The fee_amount must be a non-negative number.', 'The fee_amount may not have more than 2 decimal places.');
    }
    if ($mode === 'status') {
        kcdf_validation_required($errors, 'status', $data['status'] ?? null, 'The status field is required.');
    }
    kcdf_validation_choice($errors, 'status', $data['status'] ?? null, $statuses, 'The status must be one of: active, inactive, archived.');
    return $errors;
}

function kcdf_acad_validate_batch(array $data, string $mode): array
{
    $errors = [];
    $statuses = ['upcoming', 'active', 'completed', 'cancelled'];
    if ($mode === 'create') {
        kcdf_validation_required($errors, 'program_id', $data['program_id'] ?? null, 'The program_id field is required.');
        if (isset($data['program_id']) && $data['program_id'] !== '') {
            kcdf_validation_positive_int($errors, 'program_id', $data['program_id'], 'The program_id must be a valid integer.');
        }
        kcdf_validation_required($errors, 'batch_name', $data['batch_name'] ?? null, 'The batch_name field is required.');
    }
    if (array_key_exists('batch_name', $data)) {
        kcdf_validation_text_field($errors, 'batch_name', $data['batch_name'], 255, 'The batch_name field is required.', 'The batch_name field cannot be empty.', 'The batch_name may not be greater than 255 characters.', $mode === 'create');
    }
    if (isset($data['capacity']) && (!is_numeric($data['capacity']) || (int) $data['capacity'] < 1)) {
        $errors['capacity'] = ['The capacity must be an integer of at least 1.'];
    }
    kcdf_validation_choice($errors, 'status', $data['status'] ?? null, $statuses, 'The status must be one of: upcoming, active, completed, cancelled.');
    foreach (['start_date', 'end_date'] as $field) {
        if (!empty($data[$field])) {
            kcdf_validation_date($errors, $field, $data[$field], "The {$field} must be a valid date (YYYY-MM-DD).") ;
        }
    }
    if (!empty($data['end_date']) && !empty($data['start_date']) && kcdf_identity_date((string) $data['start_date']) && $data['end_date'] <= $data['start_date']) {
        $errors['end_date'] = ['The end_date must be after the start_date.'];
    }
    return $errors;
}

function kcdf_acad_validate_session(array $data, string $mode): array
{
    $errors = [];
    $types = ['regular', 'special', 'exam', 'workshop'];
    $statuses = ['scheduled', 'completed', 'cancelled', 'postponed'];
    if ($mode === 'create') {
        kcdf_validation_required($errors, 'session_date', $data['session_date'] ?? null, 'The session_date field is required.');
        kcdf_validation_required($errors, 'session_type', $data['session_type'] ?? null, 'The session_type field is required.');
    }
    if (!empty($data['session_date'])) {
        kcdf_validation_date($errors, 'session_date', $data['session_date'], 'The session_date must be a valid date (YYYY-MM-DD).');
    }
    kcdf_validation_choice($errors, 'session_type', $data['session_type'] ?? null, $types, 'The session_type must be one of: regular, special, exam, workshop.');
    kcdf_validation_choice($errors, 'status', $data['status'] ?? null, $statuses, 'The status must be one of: scheduled, completed, cancelled, postponed.');
    foreach (['start_time', 'end_time'] as $field) {
        if (!empty($data[$field])) {
            kcdf_validation_time($errors, $field, $data[$field], "The {$field} must be a valid time (HH:MM).") ;
        }
    }
    if (!empty($data['end_time']) && !empty($data['start_time']) && $data['end_time'] <= $data['start_time']) {
        $errors['end_time'] = ['The end_time must be after the start_time.'];
    }
    return $errors;
}

function kcdf_acad_transaction(Medoo\Medoo $database, callable $callback)
{
    $pdo = $database->pdo;
    $sqlite = $database->type === 'sqlite';
    if ($sqlite) {
        $pdo->exec('BEGIN IMMEDIATE');
    } else {
        $pdo->beginTransaction();
    }
    try {
        $result = $callback();
        if ($sqlite) {
            $pdo->exec('COMMIT');
        } else {
            $pdo->commit();
        }
        return $result;
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) {
            if ($sqlite) $pdo->exec('ROLLBACK');
            else $pdo->rollBack();
        }
        throw $exception;
    }
}

function kcdf_acad_lock_batch(Medoo\Medoo $database, int $id): ?array
{
    if ($database->type === 'sqlite') {
        return kcdf_acad_batch($database, $id, false);
    }
    $statement = $database->pdo->prepare('SELECT * FROM student_batches WHERE id = :id FOR UPDATE');
    $statement->execute([':id' => $id]);
    $row = $statement->fetch(PDO::FETCH_ASSOC);
    return is_array($row) ? kcdf_identity_cast_ids($row) : null;
}

function kcdf_acad_lock_session(Medoo\Medoo $database, int $id): ?array
{
    if ($database->type === 'sqlite') {
        return kcdf_identity_one($database, 'batch_sessions', ['id' => $id]);
    }
    $statement = $database->pdo->prepare('SELECT * FROM batch_sessions WHERE id = :id FOR UPDATE');
    $statement->execute([':id' => $id]);
    $row = $statement->fetch(PDO::FETCH_ASSOC);
    return is_array($row) ? kcdf_identity_cast_ids($row) : null;
}

function kcdf_acad_lock_enrollment(Medoo\Medoo $database, int $id): ?array
{
    if ($database->type === 'sqlite') {
        return kcdf_identity_one($database, 'enrollments', ['id' => $id]);
    }
    $statement = $database->pdo->prepare('SELECT * FROM enrollments WHERE id = :id FOR UPDATE');
    $statement->execute([':id' => $id]);
    $row = $statement->fetch(PDO::FETCH_ASSOC);
    return is_array($row) ? kcdf_identity_cast_ids($row) : null;
}

function kcdf_acad_profile(Medoo\Medoo $database, ?int $id): ?array
{
    return $id ? kcdf_identity_profile($database, $id) : null;
}

function kcdf_acad_enrollment(Medoo\Medoo $database, int $id, bool $includeEnrolledBy = false): ?array
{
    $row = kcdf_identity_one($database, 'enrollments', ['id' => $id]);
    if ($row === null) {
        return null;
    }
    $row['family'] = kcdf_identity_family($database, (int) $row['family_id']);
    $row['member'] = kcdf_acad_profile($database, (int) $row['member_id']);
    $row['batch'] = kcdf_acad_batch($database, (int) $row['batch_id']);
    if ($includeEnrolledBy) {
        $row['enrolled_by'] = kcdf_acad_profile($database, isset($row['enrolled_by_member_id']) ? (int) $row['enrolled_by_member_id'] : null);
    }
    return $row;
}

function kcdf_acad_primary_in_family(Medoo\Medoo $database, int $profileId, int $familyId): bool
{
    return $database->has('family_members', [
        'family_id' => $familyId,
        'profile_id' => $profileId,
        'member_role' => 'primary',
        'status' => 'active',
    ]);
}

function kcdf_acad_enrollment_access(Medoo\Medoo $database, array $jwt, array $enrollment, string $scope): bool
{
    if (kcdf_identity_is_admin($jwt)) {
        return true;
    }
    if ($scope === 'view' && kcdf_acad_primary_in_family($database, kcdf_identity_id($jwt), (int) $enrollment['family_id'])) {
        return true;
    }
    if ($scope === 'view') {
        return (int) $enrollment['member_id'] === kcdf_identity_id($jwt);
    }
    return $scope === 'cancel' && kcdf_acad_primary_in_family($database, kcdf_identity_id($jwt), (int) $enrollment['family_id']);
}
