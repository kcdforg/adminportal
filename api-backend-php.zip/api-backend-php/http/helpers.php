<?php

declare(strict_types=1);

function kcdf_json_encode($payload): string
{
    return json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
}

function kcdf_json_error(string $code, string $message, int $status = 400, array $details = []): void
{
    http_response_code($status);
    $payload = [
        'success' => false,
        'error' => [
            'code' => $code,
            'message' => $message,
        ],
    ];

    if ($details !== []) {
        $payload['error']['details'] = $details;
    }

    echo kcdf_json_encode($payload);
    exit;
}

function kcdf_json_response($payload, int $status = 200): void
{
    http_response_code($status);
    echo kcdf_json_encode(['success' => true, 'data' => $payload]);
    exit;
}

function kcdf_json_success($data = null, string $message = 'OK', int $status = 200): void
{
    $payload = ['success' => true, 'message' => $message];
    if ($data !== null) {
        $payload['data'] = $data;
    }

    http_response_code($status);
    echo kcdf_json_encode($payload);
    exit;
}

function kcdf_read_json_body(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || $raw === '') {
        return [];
    }

    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        kcdf_json_error('MALFORMED_JSON', 'Request body must be valid JSON.', 400, [
            'raw' => 'The request body could not be decoded as JSON.',
        ]);
    }

    return $decoded;
}

function kcdf_route_param(string $name, $default = null)
{
    $params = $_SERVER['ROUTE_PARAMS'] ?? [];
    if (!is_array($params)) {
        return $default;
    }

    return array_key_exists($name, $params) ? $params[$name] : $default;
}
