<?php

declare(strict_types=1);

namespace Kcdf\Repositories;

use Medoo\Medoo;

final class ProfileRepository
{
    public function __construct(private Medoo $database)
    {
    }

    public function rolesForProfile(int $profileId): array
    {
        $roles = [];
        $familyIds = [];
        $familyMembers = $this->database->select('family_members', ['family_id', 'member_role'], [
            'profile_id' => $profileId,
            'status' => 'active',
        ]) ?? [];

        foreach ($familyMembers as $row) {
            $familyIds[] = (int) $row['family_id'];
            $memberRole = (string) $row['member_role'];
            if ($memberRole === 'primary') {
                $roles[] = 'family_primary';
            } elseif ($memberRole === 'normal') {
                $roles[] = 'family_normal';
            } elseif ($memberRole === 'student') {
                $roles[] = 'family_student';
            }
        }

        if ($this->database->has('trainers', ['profile_id' => $profileId, 'status' => 'active'])) {
            $roles[] = 'trainer';
        }

        $adminRoles = $this->database->select('admins', 'admin_role', [
            'profile_id' => $profileId,
            'status' => 'active',
        ]) ?? [];
        $roleMap = [
            'super_admin' => 'admin_super',
            'program_manager' => 'admin_program_manager',
            'accounts' => 'admin_accounts',
            'readonly' => 'admin_readonly',
        ];
        foreach ($adminRoles as $adminRole) {
            if (isset($roleMap[$adminRole])) {
                $roles[] = $roleMap[$adminRole];
            }
        }

        $roles = array_values(array_unique($roles));
        sort($roles);
        $familyIds = array_values(array_unique($familyIds));
        sort($familyIds);

        return ['roles' => $roles, 'family_ids' => $familyIds];
    }

    public function findById(int $profileId): ?array
    {
        $profile = $this->database->get('member_profiles', [
            'id',
            'first_name',
            'middle_name',
            'last_name',
            'date_of_birth',
            'gender',
            'mobile',
            'email',
            'photo_url',
            'blood_group',
            'status',
        ], ['id' => $profileId]);

        return is_array($profile) ? $profile : null;
    }
}
