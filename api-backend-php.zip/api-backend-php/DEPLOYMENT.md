# Deployment and Cutover

This runtime is a candidate replacement for the Slim API, not a production
readiness declaration. Keep the Slim deployment available as the rollback
target until the plain-PHP runtime has passed staging acceptance.

## Runtime requirements

- Apache 2.4 or compatible with `mod_rewrite` enabled and `AllowOverride
  FileInfo Options` for this directory. The runtime depends on the `END`
  rewrite flag and the `.htaccess` file.
- PHP 8.1 or later with PDO and the `pdo_mysql` driver for the existing MySQL
  schema. Enable the `json` and `hash` extensions; use a maintained PHP build
  with its standard secure random-number implementation.
- A MySQL-compatible database provisioned independently from this deployment.
  Do not run schema setup or migrations against shared/production data as part
  of a cutover test.
- The web process must be able to create and append files under
  `api-backend-php/storage/logs/`. Keep that directory outside source control
  and grant write access only to the web-service account.

## Document root and rewrite rules

Set Apache's `DocumentRoot` to the `api-backend-php/` directory itself. Do not
expose the repository root or the parent directory. The root `.htaccess`:

- denies access to dotfiles and the `config/`, `libraries/`, `services/`, and
  `storage/` paths;
- denies requests made directly to PHP files below `api/`, while permitting an
  original `/api/v1/...` request to be internally rewritten to `api/index.php`;
- sends every `/api/v1` request through that single front controller and
  preserves its query string.

The app is not served by Apache as a root/site fallback: requests outside
`/api/v1` are not API routes. FastRoute treats a trailing slash as a distinct
path, so a registered endpoint with an added trailing slash returns 404.
Unknown `/api/v1` paths return the JSON 404 envelope; an unsupported method on
a known path returns JSON 405 and an `Allow` header.

Example virtual-host directory configuration (adjust paths and TLS to the
target host):

```apache
<Directory "/srv/www/api-backend-php">
    Require all granted
    AllowOverride FileInfo Options
</Directory>
```

`apachectl -t` checks the main Apache configuration only; it does not prove
that a deployed virtual host honors this `.htaccess`. Verify the deployed
document root and rewrite/access behavior with the staging checks below.

## Environment

Set variables in the service environment where possible. The optional local
`.env` file is a simple `KEY=value` format; do not commit it or put secrets in
source control. The `.htaccess` denies direct dotfile requests, but environment
injection is preferred.

| Variable | Purpose | Production guidance |
| --- | --- | --- |
| `APP_NAME` | Runtime name | Optional |
| `APP_ENV` | Environment label | Set to `production` |
| `APP_DEBUG` | Enables Medoo query logging | Set to `false` |
| `DB_TYPE` | PDO driver | Use `mysql` |
| `DB_HOST`, `DB_PORT` | Database host and port | Set to the private database endpoint |
| `DB_DATABASE` | Existing database name | Use the approved production database |
| `DB_USERNAME`, `DB_PASSWORD` | Database credentials | Use a least-privilege service account |
| `JWT_SECRET` | HMAC signing secret | Supply a unique secret of at least 32 characters; never reuse a development value |
| `JWT_ALGORITHM` | HMAC algorithm | Use `HS256`, `HS384`, or `HS512` consistently with existing tokens |
| `JWT_ACCESS_TTL` | Access-token lifetime in seconds | Coordinate with consumers |
| `JWT_REFRESH_TTL` | Refresh-token lifetime in seconds | Coordinate with consumers |
| `CORS_ALLOWED_ORIGINS` | Comma-separated browser origins | List only the exact deployed admin and parent origins |
| `LOG_LEVEL` | Application log threshold | Use an operationally appropriate level, normally `warning` or `error` |

The default JWT secret is empty and startup validation fails until a strong
secret is configured. The current code defaults `APP_DEBUG` to `true` when it
is unset; production configuration must explicitly set `APP_DEBUG=false`.

## Staging acceptance

Use a disposable database populated from the unchanged schema and test-only
data. Never use production credentials or records for these checks.

1. Run the PHP checks from the runtime root:

   ```sh
   php tests/phase1-smoke.php
   php tests/phase5-payments.php
   php tests/phase6-community-notifications.php
   php tests/phase7-parity.php
   ```

   The feature checks require PHP with PDO SQLite. Run the broader feature
   suites against a disposable MySQL database as well before cutover.
2. Configure a staging virtual host with `DocumentRoot` set to this directory,
   a production-like PHP handler, required extensions, environment variables,
   and the restricted log-directory permissions. Verify that the log is
   created and writable without making it publicly accessible.
3. Through the actual Apache virtual host (not only PHP's built-in server),
   check a REST path with a path parameter and query string, JSON request
   bodies, preflight `OPTIONS`, a trailing slash, an unknown route, and an
   unsupported method. Confirm JSON content types, status codes, response
   envelopes, parameter values, and query behavior.
4. Confirm direct requests to `/api/groups/index.php`,
   `/api/index.php`, `/config/config.php`, `/libraries/`, `/services/`, and
   `/storage/` are denied, and that unknown `/api/v1/...` routes still reach
   the JSON 404 response.
5. Exercise missing configured handler behavior in an isolated test copy (do
   not rename or remove a deployed endpoint); it must return the JSON
   `ROUTE_HANDLER_NOT_FOUND` 500 envelope.
6. Build and exercise the admin app against staging. Verify its login,
   refresh, logout, `/auth/me`, and representative list/mutation calls against
   unchanged `/api/v1` URLs. The parent app currently has the same API base URL
   in its environments but no active API service callers were found in the
   checked source tree; verify any consumer functionality introduced before
   its cutover.
7. Compare representative success and error responses with the Slim staging
   service, including role restrictions, pagination/filtering, and mutation
   effects. Require business-owner acceptance before changing traffic.

## Cutover and rollback

1. Deploy the PHP runtime to staging first and complete every acceptance item.
2. Back up the deployment configuration and confirm the Slim service remains
   deployable and its database compatibility is unchanged.
3. Switch staging traffic only after client, API, database, logging, and
   authorization checks are accepted. For production, perform a separately
   approved traffic switch with monitoring and an operator present.
4. Monitor HTTP 4xx/5xx rates, Apache/PHP errors, database errors, and
   application logs. Do not log credentials, passwords, access tokens, or
   refresh tokens.
5. On a regression, restore the prior routing/reverse-proxy target to Slim;
   do not roll back by destructively restoring a database snapshot unless the
   database owner has approved that recovery. Keep schema/data compatibility
   intact so the old service can resume handling traffic.

## Known operational differences and cutover blockers

- This runtime uses a manually maintained FastRoute registry and direct PHP
  endpoint files instead of Slim's middleware/container lifecycle.
- Apache `.htaccess` behavior, PHP extensions, environment injection, log
  permissions, CORS, and the actual DB driver are deployment-specific and
  cannot be proven by the repository-only route test.
- The current development environment has no PHP CLI or PDO SQLite, and its
  Docker daemon is unavailable. Feature tests and HTTP-level checks therefore
  remain unexecuted here.
- The admin and parent app URLs still point at the existing `/api/v1` paths,
  but neither has been exercised against this runtime in a deployed
  environment. The parent app has no active API callers in the source tree
  inspected for this phase.
- Production cutover is blocked until staging acceptance, feature tests, and
  consumer integration are verified. Keep Slim available as the rollback
  target until those checks and business-owner acceptance are complete.
